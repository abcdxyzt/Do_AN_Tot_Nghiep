<?php
require 'db.php';
$sql = 'SELECT * FROM sanpham';
$statement = $connection->prepare($sql);
$statement->execute();

$list_san_pham = $statement->fetchAll(PDO::FETCH_OBJ);
?>
<?php require 'header_admin.php'; ?>
<title>DANH SÁCH SẢN PHẨM</title>
<h1 style=" margin-top: 50px; margin-bottom: 30px; color: red; text-align: center; font-family: 'Times New Roman', Times, serif;"> DANH SÁCH CÁC SẢN PHẨM CỦA CỬA HÀNG </h1>
<link rel="stylesheet" type="text/css" href="CSS/List_San_Pham.css">

<div class="table-container">
  <table id="list_tables" style="border: 2px solid black; border-collapse: collapse; font-family: 'Times New Roman', Times, serif;">
    <tr>
      <th style="text-align: center; border: 1px solid black; padding: 8px;">Mã SP</th>
      <th style="text-align: center; border: 1px solid black; padding: 8px;">Tên sản phẩm</th>
      <th style="text-align: center; border: 1px solid black; padding: 8px;">Giá sản phẩm</th>
      <th style="text-align: center; border: 1px solid black; padding: 8px;">Số lượng</th>
      <th style="text-align: center; border: 1px solid black; padding: 8px;">Ảnh</th>
      <th style="text-align: center; border: 1px solid black; padding: 8px;">Hành động (Sửa, Xóa)</th>
    </tr>
    <?php foreach($list_san_pham as $san_pham): ?>
    <tr>
      <td style="border: 1px solid black; padding: 8px;"><?= $san_pham->ma_san_pham; ?></td>
      <td style="border: 1px solid black; padding: 8px;"><?= $san_pham->ten_san_pham; ?></td>
      <td style="border: 1px solid black; padding: 8px;"><?= $san_pham->gia_san_pham; ?></td>
      <td style="border: 1px solid black; padding: 8px;"><?= $san_pham->so_luong; ?></td>
      <td style="border: 1px solid black; padding: 8px;"><?= $san_pham->anh_san_pham; ?></td>
      <td style="border: 1px solid black; padding: 8px;">
        <a href="edit.php?id=<?= $san_pham->id ?>" class="btn btn-info">Chỉnh sửa thông tin sản phẩm</a>
        <a onclick="return confirm('Bạn có muốn xóa sản phẩm khỏi hệ thống?')" href="delete.php?id=<?= $san_pham->id ?>" class='btn btn-danger'>Xóa sản phẩm</a>
      </td>
    </tr>
    <?php endforeach; ?>
  </table>
  <ul>
    <li class="nav-item">
      <a class="nav-link" href="create.php">Nhập sản phẩm mới</a>
    </li>
  </ul>
</div>
<?php require 'footer.php'; ?>
