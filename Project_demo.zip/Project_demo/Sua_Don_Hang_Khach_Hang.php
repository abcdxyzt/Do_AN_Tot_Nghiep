<?php
require 'db.php';

// Hàm lấy danh sách mã sản phẩm từ cơ sở dữ liệu
function getMaSanPhamList() {
    global $connection;
    $sql = 'SELECT ma_san_pham FROM sanpham';
    $statement = $connection->prepare($sql);
    $statement->execute();
    $result = $statement->fetchAll(PDO::FETCH_COLUMN);
    return $result;
}

// Lấy thông tin đơn hàng cần sửa từ cơ sở dữ liệu
if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = 'SELECT * FROM donhang WHERE id = :id';
    $statement = $connection->prepare($sql);
    $statement->execute([':id' => $id]);
    $don_hang = $statement->fetch(PDO::FETCH_OBJ);
}

// Cập nhật thông tin đơn hàng khi người dùng nhấn nút Cập nhật
if(isset($_POST['update'])) {
    $id = $_POST['ma_don_hang'];
    $ma_san_pham = $_POST['ma_san_pham'];
    $so_luong = $_POST['so_luong'];
    $thong_tin_nguoi_mua = $_POST['thong_tin_nguoi_mua'];
    $dia_chi_khach_hang = $_POST['dia_chi_khach_hang'];
    $so_dien_thoai_khach_hang = $_POST['so_dien_thoai_khach_hang'];

    // Thực hiện cập nhật thông tin đơn hàng vào cơ sở dữ liệu
    $sql = 'UPDATE donhang SET ma_san_pham = :ma_san_pham, so_luong_san_pham = :so_luong, thong_tin_nguoi_mua = :thong_tin_nguoi_mua, dia_chi_khach_hang = :dia_chi_khach_hang, so_dien_thoai_khach_hang = :so_dien_thoai_khach_hang WHERE id = :id';
    $statement = $connection->prepare($sql);
    if($statement->execute([':ma_san_pham' => $ma_san_pham, ':so_luong' => $so_luong, ':thong_tin_nguoi_mua' => $thong_tin_nguoi_mua, ':dia_chi_khach_hang' => $dia_chi_khach_hang, ':so_dien_thoai_khach_hang' => $so_dien_thoai_khach_hang, ':id' => $id])) {
        header("Location: Xem_Don_Hang_Khach_Hang.php");
    }
}

// Xóa đơn hàng khi người dùng nhấn nút Xóa
if(isset($_POST['delete'])) {
    // Thực hiện xóa đơn hàng khỏi cơ sở dữ liệu
    $sql = 'DELETE FROM donhang WHERE id = :id';
    $statement = $connection->prepare($sql);
    if($statement->execute([':id' => $id])) {
        header("Location: Xem_Don_Hang_Khach_Hang.php");
    }
}
?>

<?php require 'header_guest.php'; ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <h1 style="color: red; font-size: 19px; text-align: center; font-family: 'Times New Roman', Times, serif;"> SỬA ĐƠN HÀNG </h1>
            <div class="form-container" style="background-color: whitesmoke; width: 40%; padding: 20px; border: 2px solid blue; border-radius: 10px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.5);">
                <form method="POST">
                    <label for="ma_don_hang">Mã đơn hàng:</label>
                    <input type="text" id="ma_don_hang" name="ma_don_hang" value="<?= $don_hang->id; ?>" readonly><br><br>
                    
                    <label for="ma_san_pham">Mã sản phẩm:</label>
                    <select id="ma_san_pham" name="ma_san_pham">
                        <?php foreach(getMaSanPhamList() as $ma_san_pham): ?>
                            <option value="<?= $ma_san_pham; ?>" <?= ($ma_san_pham == $don_hang->ma_san_pham) ? 'selected' : ''; ?>><?= $ma_san_pham; ?></option>
                        <?php endforeach; ?>
                    </select><br><br>
                    
                    <label for="so_luong">Số lượng:</label>
                    <input type="number" id="so_luong" name="so_luong" value="<?= $don_hang->so_luong_san_pham; ?>" min="1" max="1000"><br><br>
                    
                    <label for="thong_tin_nguoi_mua">Thông tin người mua:</label>
                    <input type="text" id="thong_tin_nguoi_mua" name="thong_tin_nguoi_mua" value="<?= $don_hang->thong_tin_nguoi_mua; ?>"><br><br>

                    <label for="dia_chi_khach_hang">Địa chỉ khách hàng:</label>
                    <input type="text" id="dia_chi_khach_hang" name="dia_chi_khach_hang" value="<?= $don_hang->dia_chi_khach_hang; ?>"><br><br>
                    
                    <label for="so_dien_thoai_khach_hang">Số điện thoại khách hàng:</label>
                    <input type="text" id="so_dien_thoai_khach_hang" name="so_dien_thoai_khach_hang" value="<?= $don_hang->so_dien_thoai_khach_hang; ?>"><br><br>
                    
                    <div style="text-align: center;">
                        <button type="submit" name="update" class="btn-primary" style="border-radius: 10px; font-family: 'Times New Roman', Times, serif; font-weight: bold; color: blue; background-color: whitesmoke; border: 2px solid blue; padding: 10px 20px; font-size: 16px;" onmouseover="this.style.backgroundColor='#98FB98'" onmouseout="this.style.backgroundColor='whitesmoke'">Cập nhật đơn hàng</button>
                        <button type="submit" name="delete" onclick="return confirm('Bạn có chắc muốn xóa đơn hàng này không?')" class="btn-danger" style="border-radius: 10px; font-family: 'Times New Roman', Times, serif; font-weight: bold; color: blue; background-color: whitesmoke; border: 2px solid blue; padding: 10px 20px; font-size: 16px;" onmouseover="this.style.backgroundColor='#98FB98'" onmouseout="this.style.backgroundColor='whitesmoke'">Xóa đơn hàng</button>
                        <button type="button" onclick="window.location.href='Xem_Don_Hang_Khach_Hang.php'" class="btn-secondary" style="border-radius: 10px; font-family: 'Times New Roman', Times, serif; font-weight: bold; color: blue; background-color: whitesmoke; border: 2px solid blue; padding: 10px 20px; font-size: 16px;" onmouseover="this.style.backgroundColor='#98FB98'" onmouseout="this.style.backgroundColor='whitesmoke'">Trở lại</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require 'footer.php'; ?>
