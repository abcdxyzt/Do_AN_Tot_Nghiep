<?php
session_start();

// Kiểm tra nếu người dùng đã đăng nhập thì chuyển hướng đến trang chính
if(isset($_SESSION['email'])) {
    header("Location: index.php");
    exit;
}

// Xử lý yêu cầu gửi mã xác thực
if(isset($_POST['submit'])) {
    require 'db.php';
    $email_or_phone = $_POST['email_or_phone'];
    // Kiểm tra xem email hoặc số điện thoại có tồn tại trong CSDL hay không
    $sql = 'SELECT * FROM user WHERE email = :email_or_phone OR phone = :email_or_phone';
    $statement = $connection->prepare($sql);
    $statement->execute([':email_or_phone' => $email_or_phone]);
    $user = $statement->fetch(PDO::FETCH_ASSOC); 

    if($user) {
        // Gửi mã xác thực đến email hoặc số điện thoại của người dùng
        // Lưu mã xác thực vào session và chuyển hướng đến trang nhập mã xác thực
        $_SESSION['verification_code'] = mt_rand(100000, 999999); // Tạo mã xác thực ngẫu nhiên
        $_SESSION['email_or_phone'] = $email_or_phone;
        header('Location: nhap_ma_xac_thuc.php');
        exit;
    } else {
        $error_message = "Email hoặc số điện thoại không tồn tại trong hệ thống.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quên mật khẩu</title>
    <link rel="stylesheet" type="text/css" href="CSS/style.css">
</head>
<body>
    <div class="container">
        <h2>Quên mật khẩu</h2>
        <?php if(isset($error_message)) { ?>
            <div class="error"><?php echo $error_message; ?></div>
        <?php } ?>
        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
            <label for="email_or_phone">Nhập email hoặc số điện thoại:</label>
            <input type="text" id="email_or_phone" name="email_or_phone" required>
            <button type="submit" name="submit">Gửi mã xác thực</button>
        </form>
        <p><a href="login.php">Quay lại đăng nhập</a></p>
    </div>
</body>
</html>
