
    <!-- Optional JavaScript  Phần footer của khách hàng-->
   
    <marquee direction="left"  style="background: palegreen; position: fixed; bottom: 0; left: 0; width: 100%; text-align: justify; font-size: 22px; font-weight: bold; color: red; animation: marrquee 15s linear infinite;" scrollamount="10" scrollDelay = '0.01' >
            CỬA HÀNG THỨC ĂN CHĂN NUÔI KANJI FEED VĂN LỘC - ĐỊA CHỈ: THÔN 2, THÔN 3 - BA TRẠI - BA VÌ - HÀ NỘI. THÔNG TIN LIÊN HỆ: SĐT/ZALO: 0356461193 - 0969630992. HÂN HẠNH PHỤC VỤ QUÝ KHÁCH.
    </marquee>      
    <script src="https://..." crossorigin="anonymous"></script>
  </body>
</html>