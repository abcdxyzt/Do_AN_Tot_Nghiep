<?php
require 'db.php';

if (isset($_POST['btn_Them_Vao_Gio_Hang'])) {
    $id_san_pham = $_POST['id_san_pham'];
    $so_luong_san_pham = $_POST['so_luong_san_pham'];
    $gia_san_pham = $_POST['gia_san_pham'];

    // Tính toán thành tiền
    $thanh_tien = $so_luong_san_pham * $gia_san_pham;

    // Thực hiện thêm vào giỏ hàng
    $sql = "INSERT INTO Bang_Gio_Hang_Khach_Hang (ma_san_pham, ten_san_pham, so_luong_san_pham, don_gia, thanh_tien) VALUES (:ma_san_pham, :ten_san_pham, :so_luong_san_pham, :don_gia, :thanh_tien)";
    $statement = $connection->prepare($sql);
    $statement->execute([
        'ma_san_pham' => $id_san_pham,
        'ten_san_pham' => $_POST['ten_san_pham'],
        'so_luong_san_pham' => $so_luong_san_pham,
        'don_gia' => $gia_san_pham,
        'thanh_tien' => $thanh_tien
    ]);

    // Chuyển hướng người dùng sau khi thêm vào giỏ hàng
    header("Location: Gio_Hang_Khach_Hang.php");
    exit();
}
?>
