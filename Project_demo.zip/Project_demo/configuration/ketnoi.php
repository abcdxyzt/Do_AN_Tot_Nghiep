<?php 
	$severname = "localhost";
	$username = "root";
	$password = "";
	$database = "project_demo";

	$conn = mysqli_connect($severname,$username,$password,$database);
	if(!$conn)
	{
		echo (" Kết nối không thành công ");
	}
	else
	{
		echo (" Kết nối thành công ");
	}
?>