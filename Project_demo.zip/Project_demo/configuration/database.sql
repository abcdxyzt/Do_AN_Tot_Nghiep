create database project_demo;
use project_demo;

create table sanpham
(
  id  int(11) auto_increment primary key,
  ma_san_pham varchar(30) not null,
  ten_san_pham varchar(100) not null,
  gia_san_pham varchar(30) not null,
  anh_san_pham varchar(30) not null
);

create table donhang
(
  id  int(11) auto_increment primary key,
  ma_san_pham varchar(30) not null,
  ten_san_pham varchar(255) Not null,
  so_luong_san_pham int(11) not null,
  don_gia INT(11) NOT NULL,
  tong_so_tien INT(11) NOT NULL
  thong_tin_nguoi_mua text not null,
  dia_chi_khach_hang text not null,
  so_dien_thoai_khach_hang varchar(20) not null
);
$sql = "ALTER TABLE donhang\n"

    . "ADD COLUMN don_gia INT(11) NOT NULL AFTER so_luong_san_pham,\n"

    . "ADD COLUMN tong_so_tien INT(11) NOT NULL AFTER don_gia;";

create table user
(
  id  int(11) auto_increment primary key,
  ten_dang_nhap varchar(100) not null,
  mat_khau varchar(30) not null
);
CREATE TABLE Dang_Nhap_Quan_Tri_Vien (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    ten_dang_nhap VARCHAR(100) NOT NULL,
    mat_khau VARCHAR(30) NOT NULL
);

INSERT INTO `user`(`id`, `ten_dang_nhap`, `mat_khau`)
VALUES
(1, 'admin', '123456');

CREATE TABLE Bang_Gio_Hang_Khach_Hang (
    ma_gio_hang INT(11) not null AUTO_INCREMENT PRIMARY KEY,
    ma_san_pham varchar(30) not null,
    ten_san_pham varchar(255) Not null,
    so_luong_san_pham int(11) not null,
    don_gia INT(11) not null,
    thanh_tien INT(11) not null
);
