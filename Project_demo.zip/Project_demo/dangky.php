<!DOCTYPE html>
<html>
<head>
    <title>ĐĂNG KÝ TÀI KHOẢN</title>
    <link rel="stylesheet" href="CSS/Dang_Ky.css">
    
    <marquee direction="left" scrollamount="10" scrollDelay = '0.01' >
            CỬA HÀNG THỨC ĂN CHĂN NUÔI VĂN LỘC - ĐỊA CHỈ: BA TRẠI - BA VÌ - HÀ NỘI - SĐT/ZALO: 0356461193 - 0969630992.
        </marquee>
</head>
<body>

    <div class="container">
        <div style="height: auto;" class="card">
            <h2> NHẬP THÔNG TIN ĐỂ ĐĂNG KÝ</h2>
            <form method="POST" action="">
            <label for="id">ID:</label>
                <div class="inputBox">                    
                    <input type="text" id="id" name="id" required>                
                </div>

                <label for="ten_dang_nhap">Tên đăng nhập:</label>
                <div class="inputBox">                    
                    <input type="text" id="ten_dang_nhap" name="ten_dang_nhap" required>            
                </div>

                <label for="mat_khau">Mật khẩu:</label>
                <div class="inputBox">                    
                    <input type="password" id="mat_khau" name="mat_khau" required>           
                </div>
                <button style="width: auto;" type="submit" name="dangky"class="button_dangky">ĐĂNG KÝ</button>
                <ul style="text-align: justify;" class="custom-list">
                <li style="margin-bottom: 0.5cm;">
                    <a
                        href='login.php'>Đăng nhập nếu có tài khoản
                    </a>
                </li>

                <li style="margin-bottom: 0.5cm;">
                    <a
                        href='DangNhap_QuanTriVien.php'>Đăng nhập quản trị viên
                    </a>
                </li>
                <li>
                    <a style="text-align: left;" href='GioiThieuVeTrang.php'>Trở lại</a>
                </li>               
            </form>
        </div>                   
    </div>
    
    <?php
    if(isset($_POST['dangky'])) {
        // Thực hiện đăng ký tài khoản
        $id = $_POST['id'];
        $ten_dang_nhap = $_POST['ten_dang_nhap'];
        $mat_khau = $_POST['mat_khau'];
        
        // Kiểm tra xem các trường đã được điền đầy đủ hay không
        if ($id && $ten_dang_nhap && $mat_khau) {
            // Kết nối đến cơ sở dữ liệu MySQL

            $servername = "localhost";
            $username = "root";
            $password = "";
            $database = "project_demo";
        
            $conn = mysqli_connect($servername, $username, $password, $database);
        
            // Kiểm tra kết nối
            if ($conn->connect_error) {
                die("Kết nối đến cơ sở dữ liệu thất bại: " . $conn->connect_error);
            }

            // Kiểm tra xem tên đăng nhập đã tồn tại trong cơ sở dữ liệu hay chưa
            $sql_check_duplicate = "SELECT * FROM user WHERE ten_dang_nhap='$ten_dang_nhap'";
            $result_check_duplicate = mysqli_query($conn, $sql_check_duplicate);

            if (mysqli_num_rows($result_check_duplicate) > 0) {
                echo "Tên đăng nhập đã tồn tại!";
            } else {
                // Thực hiện câu truy vấn để chèn thông tin tài khoản vào cơ sở dữ liệu
                $sql_dangky = "INSERT INTO user (id, ten_dang_nhap, mat_khau) VALUES ('$id', '$ten_dang_nhap', '$mat_khau')";
        
                if (mysqli_query($conn, $sql_dangky)) {
                    echo "Đăng ký tài khoản thành công!";
                    // Chuyển hướng đến trang đăng nhập
                    header('Location: login.php');
                } else {
                    echo "Lỗi đăng ký: " . mysqli_error($conn);
                }
            }

            // Đóng kết nối đến cơ sở dữ liệu
            mysqli_close($conn);
        }
        else
        {
            echo "Vui lòng điền đầy đủ thông tin!";
        }
    }
    ?>
    
</body>
    
</html>