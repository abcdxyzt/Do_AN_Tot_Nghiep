<?php require 'db.php'; ?>

<?php
$sql = 'SELECT donhang.id, donhang.ma_san_pham, sanpham.ten_san_pham, donhang.so_luong_san_pham, donhang.gia_san_pham AS gia_san_pham, (donhang.so_luong_san_pham * donhang.gia_san_pham) AS thanh_tien, donhang.thong_tin_nguoi_mua, donhang.dia_chi_khach_hang, donhang.so_dien_thoai_khach_hang
        FROM donhang
        INNER JOIN sanpham ON donhang.ma_san_pham = sanpham.ma_san_pham';

$statement = $connection->prepare($sql);
$statement->execute();
$list_don_hang = $statement->fetchAll(PDO::FETCH_OBJ);
?>

<?php require 'header_admin.php'; ?>
<title> Các đơn hàng </title>
<h1 style="color: red; font-size: 19px; margin-top: 50px; margin-bottom: 30px; text-align: center; font-family: 'Times New Roman', Times, serif;"> BẢNG ĐƠN HÀNG </h1>
<div class="Don_Hang">
    <table id="list_tables" style="border-collapse: collapse; width: 100%; border: 2px solid black; font-family: 'Times New Roman', Times, serif;">
        <tr style="background-color: black; color: white;">
            <th style="text-align: center; padding: 10px; border: 1px solid black;">Mã đơn hàng</th>
            <th style="text-align: center; padding: 10px; border: 1px solid black;">Mã sản phẩm</th>
            <th style="text-align: center; padding: 10px; border: 1px solid black;">Tên sản phẩm</th>
            <th style="text-align: center; padding: 10px; border: 1px solid black;">Số lượng</th>
            <th style="text-align: center; padding: 10px; border: 1px solid black;">Giá sản phẩm</th>
            <th style="text-align: center; padding: 10px; border: 1px solid black;">Thành tiền</th>
            <th style="text-align: center; padding: 10px; border: 1px solid black;">Thông tin người mua</th>
            <th style="text-align: center; padding: 10px; border: 1px solid black;">Địa chỉ khách hàng</th>
            <th style="text-align: center; padding: 10px; border: 1px solid black;">Số điện thoại khách hàng</th>
            <th style="text-align: center; padding: 10px; border: 1px solid black;">Thao tác xóa đơn hàng</th>
        </tr>
        <?php foreach ($list_don_hang as $don_hang): ?>
            <tr style="border: 1px solid black;">
                <td style="text-align: center; padding: 10px; border: 1px solid black;"><?= $don_hang->id; ?></td>
                <td style="text-align: center; padding: 10px; border: 1px solid black;"><?= $don_hang->ma_san_pham; ?></td>
                <td style="text-align: left; padding: 10px; border: 1px solid black;"><?= $don_hang->ten_san_pham; ?></td>
                <td style="text-align: center; padding: 10px; border: 1px solid black;"><?= $don_hang->so_luong_san_pham; ?></td>
                <td style="text-align: center; padding: 10px; border: 1px solid black;"><?= number_format($don_hang->gia_san_pham); ?></td>
                <td style="text-align: center; padding: 10px; border: 1px solid black;"><?= number_format($don_hang->thanh_tien); ?></td>
                <td style="text-align: center; padding: 10px; border: 1px solid black;"><?= $don_hang->thong_tin_nguoi_mua; ?></td>
                <td style="text-align: center; padding: 10px; border: 1px solid black;"><?= $don_hang->dia_chi_khach_hang ?></td>
                <td style="text-align: center; padding: 10px; border: 1px solid black;"><?= $don_hang->so_dien_thoai_khach_hang ?></td>
                <td style="text-align: center; padding: 10px; border: 1px solid black;">
                    <a onclick="return confirm('Bạn có muốn xóa đơn hàng đã chọn khỏi hệ thống')" href="delete_don_hang.php?id=<?= $don_hang->id ?>" class='btn btn-danger'>Xóa đơn hàng</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</div>
<?php require 'footer.php'; ?>
