<!doctype html>
<html lang="en">
<head>   
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="CSS/header_admin.css">
    <!-- Menu ngang -->
    <nav>
        <ul>
            <li>
                <a class="nav-link" href="list_san_pham.php">Xem danh sách các sản phẩm</a>
            </li>
            <li>
                <a class="nav-link" href="list_don_hang.php">Xem danh sách đơn hàng</a>
            </li>
            <li>
                <a href='quan_ly_tai_khoan_nguoi_dung.php'> Quản lý tài khoản người dùng </a>
            </li>
            <li>
                <a href='logout.php'> Đăng xuất tài khoản </a>
            </li>
        </ul>
    </nav>
</head>
</html>
