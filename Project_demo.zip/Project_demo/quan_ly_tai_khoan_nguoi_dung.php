<?php
// Kết nối đến cơ sở dữ liệu
require 'db.php';

// Lấy dữ liệu từ bảng user
$sql = 'SELECT * FROM user';
$statement = $connection->prepare($sql);
$statement->execute();
$users = $statement->fetchAll(PDO::FETCH_OBJ);
?>

<!DOCTYPE html>
<html lang="en">
<head>    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý tài khoản người dùng</title>  
    <link rel="stylesheet" type="text/css" href="CSS/quan_ly_tai_khoan_nguoi_dung.css">
</head>

<body>
    <p style=" font-weight: bold; font-size: 20px; text-align: center; margin-top: 1.5cm; color: blue;"> CÁC TÀI KHOẢN NGƯỜI DÙNG CỦA HỆ THỐNG </p>
    <table>
        <tr>
            <th class="Tieu_De_Cot_Ma_ID">ID Khách hàng</th>
            <th class="Tieu_De_Cot_Ten_Dang_Nhap">Tên đăng nhập tài khoản</th>
            <th class="Tieu_De_Cot_Mat_Khau">Mật khẩu</th>
            <th class="Tieu_De_Cot_Hanh_Dong">Hành động</th>
        </tr>
        <?php foreach ($users as $user): ?>
        <tr>
            <td class="ma_id"><?= $user->id; ?></td>
            <td class="ten_dang_nhap"><?= $user->ten_dang_nhap; ?></td>
            <td class="mat_khau"><?= $user->mat_khau; ?></td>
            <td class="xoa_tai_khoan">
                <a href="xoa_tai_khoan_nguoi_dung.php?id=<?= $user->id; ?>" onclick="return confirm('Bạn có chắc muốn xóa tài khoản này không?')">Xóa tài khoản</a>
                <br/>
                <a href="sua_nguoi_dung.php?id=<?= $user->id; ?>" onclick>Sửa thông tin đăng nhập</a>
            </td>

        </tr>
        <?php endforeach; ?>
    </table>
</body>
<?php require 'header_admin.php'; ?>
<?php require 'footer.php'; ?>
</html>
