<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sửa thông tin tài khoản</title>
    <style>
        body {
            background-color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        form {
            background-color: whitesmoke;
            padding: 20px;
            border-radius: 6px;
            text-align: center;
            border: 2px solid blue;
            box-shadow: 0px 0px 5px 2px rgba(0, 0, 255, 0.4);
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-family: 'Times New Roman', Times, serif;
            color: blue;
            text-align: left;
        }

        input[type="text"] {
            width: calc(100% - 20px);
            padding: 8px;
            border: 1px solid blue;
            border-radius: 6px;
            font-family: 'Times New Roman', Times, serif;
            color: blue;
            box-sizing: border-box;
            margin-bottom: 10px;
        }

        button[type="submit"], button[name="bt_Tro_Lai"] {
            background-color: whitesmoke;
            color: blue;
            padding: 10px 20px;
            border: 2px solid blue;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Times New Roman', Times, serif;
            font-size: 16px;
            box-shadow: 2px 2px 5px rgba(0, 0, 255, 0.3);
            transition: background-color 0.3s, box-shadow 0.3s;
            margin-right: 10px;
        }

        button[type="submit"]:hover, button[name="bt_Tro_Lai"]:hover {
            background-color: palegreen;
            box-shadow: 3px 3px 7px rgba(0, 0, 255, 0.5);
        }

        p {
            font-weight: bold;
            color: red;
            font-size: 19px;
            text-align: center;
        }
    </style>
</head>
<body>
    <form action="" method="POST">
        <p>SỬA TÀI KHOẢN</p>
        <?php
        // Kết nối đến cơ sở dữ liệu
        require 'db.php';

        // Kiểm tra xem có tham số id được truyền từ URL không
        if(isset($_GET['id'])) {
            // Lấy id từ URL
            $id = $_GET['id'];

            try {
                // Chuẩn bị câu truy vấn lấy thông tin tài khoản dựa trên id
                $sql = "SELECT * FROM user WHERE id = ?";
                $statement = $connection->prepare($sql);
                $statement->execute([$id]);
                $user = $statement->fetch(PDO::FETCH_OBJ);
            } catch(PDOException $e) {
                // Xử lý nếu có lỗi xảy ra
                echo "Lỗi: " . $e->getMessage();
            }
        }
        
        // Xử lý khi người dùng nhấn nút "Cập nhật tài khoản"
        if(isset($_POST['bt_Cap_Nhat_Tai_Khoan_Nguoi_Dung'])) {
            // Lấy thông tin mới từ form
            $ten_dang_nhap_moi = $_POST['tb_TenDangNhap'];
            $mat_khau_moi = $_POST['tb_MatKhau'];
            
            try {
                // Chuẩn bị câu truy vấn cập nhật thông tin tài khoản
                $sql_update = "UPDATE user SET ten_dang_nhap = ?, mat_khau = ? WHERE id = ?";
                $statement_update = $connection->prepare($sql_update);
                $statement_update->execute([$ten_dang_nhap_moi, $mat_khau_moi, $id]);
                
                // Chuyển hướng người dùng về trang quản lý tài khoản người dùng
                header("Location: quan_ly_tai_khoan_nguoi_dung.php");
                exit();
            } catch(PDOException $e) {
                // Xử lý nếu có lỗi xảy ra
                echo "Lỗi: " . $e->getMessage();
            }
        }
        ?>
        <label for="tb_MaID">Mã ID:</label>
        <input type="text" id="tb_MaID" name="tb_MaID" value="<?= $user->id ?? '' ?>" readonly>

        <label for="tb_TenDangNhap">Tên đăng nhập:</label>
        <input type="text" id="tb_TenDangNhap" name="tb_TenDangNhap" value="<?= $user->ten_dang_nhap ?? '' ?>">

        <label for="tb_MatKhau">Mật khẩu:</label>
        <input type="text" id="tb_MatKhau" name="tb_MatKhau" value="<?= $user->mat_khau ?? '' ?>">

        <button type="submit" name="bt_Cap_Nhat_Tai_Khoan_Nguoi_Dung">Cập nhật tài khoản</button>
        <button type="button" name="bt_Tro_Lai" onclick="window.history.back()">Trở lại</button>
    </form>
</body>
<?php require 'header_admin.php'; ?>
<?php require 'footer.php'; ?>
</html>
