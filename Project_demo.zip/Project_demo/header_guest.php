<!doctype html>
<html lang="en">
<head>
    <title>DANH SÁCH CÁC ĐƠN HÀNG CỦA BẠN.</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="CSS/header_Khach_Hang.css">
</head>
<body class="">
<nav>
    <ul>
        <li>
            <a href='Loi_Mo_Dau.php'>Trở về giao diện đặt hàng</a>
        </li>
        <li>
            <a href='http://zalo.me/0356461193'>Liên hệ chủ cửa hàng qua Zalo</a>
        </li>
        <li>
            <a href='DangNhap_QuanTriVien.php'>Đăng nhập quản trị viên</a>
        </li>
        <li>
            <a href='logout.php'>Đăng xuất tài khoản</a>
        </li>
    </ul>
</nav>
</body>
</html>
