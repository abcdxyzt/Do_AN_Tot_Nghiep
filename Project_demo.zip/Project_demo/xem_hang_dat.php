<?php
session_start();
// Kiểm tra nếu không có session đã đăng nhập thì chuyển hướng về trang đăng nhập
// if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
//     header("Location: login.php");
//     exit;
// }

// Kiểm tra xem dữ liệu đã được gửi từ form không
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Kiểm tra xem các biến $_POST có tồn tại không trước khi truy cập vào chúng
    $ma_san_pham = isset($_POST['ma_san_pham']) ? $_POST['ma_san_pham'] : '';
    $ten_san_pham = isset($_POST['ten_san_pham']) ? $_POST['ten_san_pham'] : '';
    $gia_san_pham = isset($_POST['gia_san_pham']) ? $_POST['gia_san_pham'] : '';
    $so_luong = isset($_POST['so_luong']) ? $_POST['so_luong'] : '';
    $thanh_tien = isset($_POST['thanh_tien']) ? $_POST['thanh_tien'] : '';
    $thong_tin_nguoi_mua = isset($_POST['thong_tin_nguoi_mua']) ? $_POST['thong_tin_nguoi_mua'] : '';
    $dia_chi = isset($_POST['dia_chi']) ? $_POST['dia_chi'] : '';
    $so_dien_thoai = isset($_POST['so_dien_thoai']) ? $_POST['so_dien_thoai'] : '';
} else {
    // Nếu không có dữ liệu được gửi từ form, chuyển hướng về trang đặt hàng
    header("Location: dat_hang.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Xem đơn hàng</title>
    <style>
        body {
            font-family: "Times New Roman", Times, serif;
            color: blue;
        }

        form {
            width: 500px; /* Tăng độ rộng form */
            margin: 50px auto;
            padding: 20px;
            border: 2px solid blue;
            border-radius: 5px;
            background-color: whitesmoke;
        }

        table {
            width: 100%;
        }

        th, td {
            padding: 8px;
            text-align: left;
        }

        button[type="submit"] {
            background-color: whitesmoke;
            color: blue;
            border: 2px solid blue; /* Thay đổi màu viền */
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
            font-family: "Times New Roman", Times, serif;
            width: auto; /* Độ rộng tự động */
            height: auto; /* Chiều cao tự động */
            display: block; /* Hiển thị dạng block để căn giữa */
            margin: 0 auto; /* Căn giữa theo chiều ngang */
        }

        button[type="submit"]:hover {
            background-color: palegreen; /* Hiệu ứng hover */
        }

        p.title {
            color: red;
            text-align: center;
        }
    </style>
</head>
<body>
    <form action="Sua_Don_Hang_Khach_Hang.php" method="POST">
        <p class="title">THÔNG TIN ĐẶT HÀNG</p> <!-- Chữ này được thêm vào form với màu đỏ và căn giữa -->

        <table>
            <tr>
                <th>Mã sản phẩm:</th>
                <td><?= $ma_san_pham ?></td>
            </tr>
            <tr>
                <th>Tên sản phẩm:</th>
                <td><?= $ten_san_pham ?></td>
            </tr>
            <tr>
                <th>Giá sản phẩm:</th>
                <td><?= $gia_san_pham ?></td>
            </tr>
            <tr>
                <th>Số lượng đặt hàng:</th>
                <td><?= $so_luong ?></td>
            </tr>
            <tr>
                <th>Thành tiền:</th>
                <td><?= $thanh_tien ?></td>
            </tr>
            <tr>
                <th>Thông tin người mua:</th>
                <td><?= $thong_tin_nguoi_mua ?></td>
            </tr>
            <tr>
                <th>Địa chỉ:</th>
                <td><?= $dia_chi ?></td>
            </tr>
            <tr>
                <th>Số điện thoai:</th>
                <td><?= $so_dien_thoai ?></td>
            </tr>
        </table>

        <button type="submit" name="sua_don_hang">Sửa đơn hàng</button> <!-- Đã thay đổi từ input type submit thành button -->
    </form>
</body>
</html>
