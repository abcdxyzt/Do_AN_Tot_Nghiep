// Hàm thực hiện tìm kiếm sản phẩm
function searchProduct() {
    var keyword = document.getElementById("searchInput").value.toLowerCase();
    var products = document.getElementsByClassName("div-bg");
    for (var i = 0; i < products.length; i++) {
        var productName = products[i].getElementsByTagName("td")[1].innerText.toLowerCase();
        var productCode = products[i].getElementsByTagName("td")[3].innerText.toLowerCase();
        if (productName.indexOf(keyword) > -1 || productCode.indexOf(keyword) > -1) {
            products[i].style.display = "";
        } else {
            products[i].style.display = "none";
        }
    }
}

// Hàm bắt sự kiện khi người dùng nhấn nút Search
document.getElementById("bt_Search").addEventListener("click", function() {
    searchProduct();
});

// Hàm bắt sự kiện khi người dùng nhấn phím Enter trong ô tìm kiếm
document.getElementById("searchInput").addEventListener("keypress", function(event) {
    if (event.key === 'Enter') {
        searchProduct();
    }
});

// Hàm bắt sự kiện khi người dùng nhấn nút Xóa
document.getElementById("bt_Xoa").addEventListener("click", function() {
    document.getElementById("searchInput").value = ""; // Xóa nội dung trong ô tìm kiếm
    window.location.reload(); // Reset lại trang web
});
