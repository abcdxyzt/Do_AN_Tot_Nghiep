function changeCount(count, price, id) {
    var countID = 'count' + id; 
    var so_luong_san_pham = 'so_luong_san_pham' + id; 
    var tong_tien_san_pham = 'tong_tien_san_pham' + id; 
    var elementCount = document.getElementById(countID);
    var elementSLSP = document.getElementById(so_luong_san_pham); 
    var elementTTSP = document.getElementById(tong_tien_san_pham);
    var countAdd = parseInt(elementCount.innerHTML);
    
    if (countAdd == 1 && count == -1) return 0;
    
    countAdd = countAdd + count; 
    elementCount.innerHTML = countAdd; 
    elementSLSP.value = countAdd; 
    var totalID = 'total' + id;
    var elementTotal = document.getElementById(totalID);
    var totalAdd = countAdd * price;
    elementTotal.innerHTML = totalAdd;
    elementTTSP.value = totalAdd;
}

function purchase(id) {
    var thong_tin_nguoi_mua = 'thong_tin_nguoi_mua' + id;
    var elementTTNM = document.getElementById(thong_tin_nguoi_mua);
    var inFor = prompt("Nhập họ tên: ");
    var DiaChi = prompt("Nhập địa chỉ: ");
    var SoDienThoai = prompt("Nhập số điện thoại: ");

    if (inFor === null || inFor === "" || DiaChi === null || DiaChi === "" || SoDienThoai === null || SoDienThoai === "") {
        alert("Hãy nhập đủ thông tin để đặt hàng.");
        return;
    }

    elementTTNM.innerHTML = "Họ tên: " + inFor + ", Địa chỉ: " + DiaChi + ", Số điện thoại: " + SoDienThoai;

    alert('Bạn đã đặt hàng thành công, thông tin đặt hàng của bạn là:\nHọ và tên: ' + inFor + '\nĐịa chỉ: ' + DiaChi + '\nSố điện thoại: ' + SoDienThoai);
}
