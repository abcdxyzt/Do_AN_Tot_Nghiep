<?php
require 'db.php';

if(isset($_GET['ma_san_pham'])) {
    $ma_san_pham = $_GET['ma_san_pham'];
    
    // Truy vấn cơ sở dữ liệu để lấy tên sản phẩm
    $sql = 'SELECT ten_san_pham FROM sanpham WHERE ma_san_pham = :ma_san_pham';
    $statement = $connection->prepare($sql);
    $statement->execute([':ma_san_pham' => $ma_san_pham]);
    $result = $statement->fetch(PDO::FETCH_ASSOC);

    // Trả về dữ liệu dưới dạng JSON
    echo json_encode($result);
} else {
    // Trường hợp không có mã sản phẩm được gửi
    echo json_encode(['error' => 'Missing ma_san_pham parameter']);
}
?>
