<?php
session_start();
if(isset($_POST['submit'])) {
    require 'db.php';
    // Kiểm tra xem trường tb_MaIDQTV đã được gửi hay chưa
    $ma_id = isset($_POST['tb_MaIDQTV']) ? $_POST['tb_MaIDQTV'] : '';
    $tai_khoan = $_POST['tai_khoan'];
    $password = $_POST['password'];
    $sql = 'SELECT * FROM dang_nhap_quan_tri_vien WHERE id=:ma_id AND ten_dang_nhap=:ten_dang_nhap';
    $statement = $connection->prepare($sql);
    $statement->execute([':ma_id' => $ma_id, ':ten_dang_nhap' => $tai_khoan ]);
    $user = $statement->fetch(PDO::FETCH_OBJ); 
    if($user != null && $user->mat_khau == $password)
    {
        $lifetime = 24*60*60;
        $_SESSION['email'] = $tai_khoan; // Sửa lại thành tên tài khoản nếu bạn muốn lưu tên tài khoản vào session
        setcookie('lifetime',time()+$lifetime);
        setcookie($tai_khoan, $password,$lifetime, "/");
        header('Location: list_san_pham.php'); // Thay đổi đường dẫn ở đây
    }
    else
    {
        echo '<p style="color:red;"> Thông báo: Mã ID, Tên đăng nhập hoặc mật khẩu không đúng. Hãy đăng nhập lại! </p>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập quản trị viên</title>
    <style>
        @import url('CSS/DangNhapQuanTriVien.css');
    </style>
    

</head>

<body>
    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">        
        <h3>ĐĂNG NHẬP QUẢN TRỊ VIÊN:</h3>
        <table>
            <tr>
                <td><label for="tb_MaIDQTV">Mã ID:</label></td>
                <td><input class="TaiKhoan" type="text" placeholder="Nhập mã ID" id="tb_MaIDQTV" name="tb_MaIDQTV" required></td>
            </tr>
            <tr>
                <td><label for="tai_khoan">Tài khoản:</label></td>
                <td><input class="TaiKhoan" type="text" placeholder="Nhập tên tài khoản" id="tai_khoan" name="tai_khoan" required></td>
            </tr>
            <tr>
                <td><label for="password">Mật khẩu:</label></td>
                <td><input class="MatKhau" type="password" placeholder="Nhập mật khẩu" id="password" name="password" required></td>
            </tr>
        </table>

        <button class="button_DangNhap_QuanTriVien" type="submit" name="submit"> ĐĂNG NHẬP QUẢN TRỊ </button>
                
        <ul style="text-align: justify;" class="custom-list">
            <li style="margin-bottom: 0.5cm;">
                <a style="text-align: left;" href='dangky.php'>Đăng ký tài khoản</a>        
            </li>
            <li style="margin-bottom: 0.5cm;">
                <a style="text-align: left;" href='login.php'>Đăng nhập người dùng</a>
            </li>
            <li style="margin-bottom: 0.5cm;">
                <a style="text-align: left;" href='GioiThieuVeTrang.php'>Trở lại</a>
            </li>
        </ul>
    </form>
    <?php require 'footer.php'; ?>
</body>     
</html>
