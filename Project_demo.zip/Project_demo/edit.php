<?php
require 'db.php';
$id = $_GET['id'];
$sql = 'SELECT * FROM sanpham WHERE id=:id';
$statement = $connection->prepare($sql);
$statement->execute([':id' => $id]);
$san_pham = $statement->fetch(PDO::FETCH_OBJ);
if (isset($_POST['ma_san_pham']) && isset($_POST['ten_san_pham'])) {
    $ma_san_pham = $_POST['ma_san_pham'];
    $ten_san_pham = $_POST['ten_san_pham'];
    $gia_san_pham = $_POST['gia_san_pham'];

    // Xử lý tải ảnh lên
    if ($_FILES['anh_san_pham']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = ''; // Thư mục lưu trữ ảnh tải lên
        $file_name = $_FILES['anh_san_pham']['name'];
        $file_tmp = $_FILES['anh_san_pham']['tmp_name'];
        move_uploaded_file($file_tmp, $upload_dir . $file_name);
        $anh_san_pham = $upload_dir . $file_name;
    } else {
        // Nếu không có ảnh mới được tải lên, sử dụng ảnh cũ
        $anh_san_pham = $_POST['anh_cu'];
    }

    // Lấy số lượng từ ô nhập
    $so_luong = $_POST['so_luong'];

    $sql = 'UPDATE sanpham SET ma_san_pham=:ma_san_pham, ten_san_pham=:ten_san_pham, gia_san_pham=:gia_san_pham, anh_san_pham=:anh_san_pham, so_luong=:so_luong WHERE id=:id';
    $statement = $connection->prepare($sql);
    if ($statement->execute([
        ':ma_san_pham' => $ma_san_pham,
        ':ten_san_pham' => $ten_san_pham,
        ':gia_san_pham' => $gia_san_pham,
        ':anh_san_pham' => $anh_san_pham,
        ':so_luong' => $so_luong,
        ':id' => $id
    ])) {
        // Cập nhật lại giá sản phẩm trong tệp Loi_Mo_Dau.php
        $update_price_script = "<script>";
        $update_price_script .= "var priceInput = document.getElementById('gia_san_pham');";
        $update_price_script .= "if(priceInput){ priceInput.value = '" . $gia_san_pham . "'; }";
        $update_price_script .= "</script>";
        echo $update_price_script;
        header("Location: /Project_demo/list_san_pham.php");
    }
}
?>
<?php require 'header_admin.php'; ?>
<div class="container">
    <form style="background-color: whitesmoke; box-shadow: 0 0 10px red (0, 0, 0, 3.0); border: 1px solid grey; width: 400px; height: 450px; margin: auto; padding: 20px; border: 1px solid #ccc; border-radius: 10px;" method="post" enctype="multipart/form-data">
        <h2 style="color:red; margin-top:0%; text-align:center; font-weight: bold;">Sửa thông tin sản phẩm</h2>
        <div>
            <label for="ma_san_pham">Mã sản phẩm</label>
            <input style="width: 90%; padding: 10px; margin-bottom: 10px; border-radius: 5px; border: 1px solid blue;" value="<?= $san_pham->ma_san_pham; ?>" type="text" name="ma_san_pham" id="ma_san_pham">
        </div>
        <div>
            <label for="ten_san_pham">Tên sản phẩm</label>
            <input style="width: 90%; padding: 10px; margin-bottom: 10px; border-radius: 5px; border: 1px solid blue;" value="<?= $san_pham->ten_san_pham; ?>" type="text" name="ten_san_pham" id="ten_san_pham">
        </div>
        <div>
            <label for="gia_san_pham">Giá sản phẩm</label>
            <input style="width: 90%; padding: 10px; margin-bottom: 10px; border-radius: 5px; border: 1px solid blue;" value="<?= $san_pham->gia_san_pham; ?>" type="text" name="gia_san_pham" id="gia_san_pham">
        </div>
        <div>
            <label for="anh_san_pham">Ảnh sản phẩm</label>
            <input style="width: 90%; padding: 10px; margin-bottom: 10px; border-radius: 5px; border: 1px solid blue;" type="file" name="anh_san_pham" id="anh_san_pham">
            <input type="hidden" name="anh_cu" value="<?= $san_pham->anh_san_pham; ?>">
        </div>
        <div>
            <label for="so_luong">Số lượng</label>
            <input style="width: 90%; padding: 10px; margin-bottom: 10px; border-radius: 5px; border: 1px solid blue;" type="number" name="so_luong" id="so_luong" value="<?= isset($san_pham->so_luong) ? $san_pham->so_luong : ''; ?>">
        </div>
        <div style="display: flex; justify-content: space-between;">
            <button style="width: 48%; padding: 10px; background-color: #4CAF50; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: bold;" type="submit">Cập nhật</button>
            <button style="width: 48%; padding: 10px; background-color: #ff9999; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: bold;" type="button" onclick="resetForm()">Xóa</button>
        </div>
    </form>
</div>
<?php require 'footer.php'; ?>

<script>
    function resetForm() {
        document.getElementById("ma_san_pham").value = "";
        document.getElementById("ten_san_pham").value = "";
        document.getElementById("gia_san_pham").value = "";
        document.getElementById("anh_san_pham").value = "";
        document.getElementById("so_luong").value = "";
    }
</script>
