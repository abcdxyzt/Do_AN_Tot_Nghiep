<?php
require 'db.php';

// Xử lý khi người dùng yêu cầu xóa đơn hàng
if(isset($_GET['id'])) {
    $id = $_GET['id'];
    // Lấy thông tin mã sản phẩm và tên sản phẩm trước khi xóa
    $sql_select = 'SELECT ma_san_pham FROM donhang WHERE id=:id';
    $statement_select = $connection->prepare($sql_select);
    if($statement_select->execute([':id' => $id])) {
        $don_hang_info = $statement_select->fetch(PDO::FETCH_OBJ);
        if($don_hang_info) {
            $ma_san_pham = $don_hang_info->ma_san_pham;
            
            // Thực hiện xóa đơn hàng
            $sql_delete = 'DELETE FROM donhang WHERE id=:id';
            $statement_delete = $connection->prepare($sql_delete);
            
            if($statement_delete->execute([':id' => $id])) {
                // Lấy tên sản phẩm tương ứng với mã sản phẩm đã xóa
                $sql_product_name = 'SELECT ten_san_pham FROM sanpham WHERE ma_san_pham=:ma_san_pham';
                $statement_product_name = $connection->prepare($sql_product_name);
                if($statement_product_name->execute([':ma_san_pham' => $ma_san_pham])) {
                    $product_name = $statement_product_name->fetch(PDO::FETCH_OBJ)->ten_san_pham;
                    
                    // Hiển thị thông báo
                    $message = "Đơn hàng có mã là: $id với mã sản phẩm là $ma_san_pham và tên sản phẩm là $product_name đã được xóa";
                    echo "<script type='text/javascript'>alert('$message');</script>";
                } else {
                    echo "Lỗi khi truy vấn tên sản phẩm";
                }
            } else {
                echo "Lỗi khi xóa đơn hàng";
            }
        } else {
            echo "Không tìm thấy thông tin đơn hàng";
        }
    } else {
        echo "Lỗi khi truy vấn thông tin đơn hàng";
    }
}

// Thực hiện truy vấn để lấy danh sách đơn hàng
$sql = 'SELECT donhang.id, donhang.ma_san_pham, sanpham.ten_san_pham, donhang.so_luong_san_pham, sanpham.gia_san_pham AS don_gia, (donhang.so_luong_san_pham * sanpham.gia_san_pham) AS tong_so_tien, donhang.thong_tin_nguoi_mua, donhang.dia_chi_khach_hang, donhang.so_dien_thoai_khach_hang
        FROM donhang
        INNER JOIN sanpham ON donhang.ma_san_pham = sanpham.ma_san_pham';

$statement = $connection->prepare($sql);
if($statement->execute()) {
    $list_don_hang = $statement->fetchAll(PDO::FETCH_OBJ);
} else {
    echo "Lỗi khi truy vấn danh sách đơn hàng";
}

// Tính tổng số tiền cần thanh toán từ các đơn đặt hàng
$tong_so_tien_thanh_toan = 0;
if(isset($list_don_hang) && !empty($list_don_hang)) {
    foreach ($list_don_hang as $don_hang) {
        $tong_so_tien_thanh_toan += $don_hang->tong_so_tien;
    }
}
?>

<?php require 'header_Loi_Mo_Dau.php';?>
<?php require 'footer.php'; ?>
<div style="padding-top: 50px;"> <!-- Thêm padding để dịch phần nội dung xuống dưới một chút -->
    <p>CÁC ĐƠN HÀNG BẠN ĐÃ ĐẶT TỪ CỬA HÀNG.</p>
    <link rel = "stylesheet"type="text/css"href = "CSS/Xem_Don_Hang_Khach_Hang.css">
    <div class="Don_Hang" style="overflow-x: auto;">
        <table>
            <tr>
                <th>Mã đơn hàng</th>
                <th>Mã sản phẩm</th>
                <th>Tên sản phẩm</th>
                <th>Số lượng (bao)</th>
                <th>Giá sản phẩm (VNĐ/bao)</th>
                <th>Thành tiền (VNĐ)</th>
                <th>Thông tin người mua</th>
                <th>Địa chỉ khách hàng</th>
                <th>Số điện thoại khách hàng</th>
                <th>Cập nhật/Xóa</th>
            </tr>
            <?php if(isset($list_don_hang) && !empty($list_don_hang)): ?>
                <?php foreach($list_don_hang as $don_hang): ?>
                <tr>
                    <td class="ma_don_hang"><?= $don_hang->id; ?></td>
                    <td class="ma_san_pham"><?= $don_hang->ma_san_pham; ?></td>
                    <td class="ten_san_pham"><?= $don_hang->ten_san_pham; ?></td>
                    <td class="so_luong_san_pham"><?= $don_hang->so_luong_san_pham; ?></td>
                    <td class="don_gia"><?= $don_hang->don_gia; ?></td>
                    <td class="tong_so_tien"><?= $don_hang->tong_so_tien; ?></td>
                    <td class="thong_tin_nguoi_mua"><?= isset($don_hang->thong_tin_nguoi_mua) ? $don_hang->thong_tin_nguoi_mua : ''; ?></td>
                    <td class="dia_chi_khach_hang"><?= isset($don_hang->dia_chi_khach_hang) ? $don_hang->dia_chi_khach_hang : ''; ?></td>
                    <td class="so_dien_thoai_khach_hang"><?= isset($don_hang->so_dien_thoai_khach_hang) ? $don_hang->so_dien_thoai_khach_hang : ''; ?></td>
                    <td>
                        <a href="Sua_Don_Hang_Khach_Hang.php?id=<?= $don_hang->id ?>">Chỉnh sửa đơn hàng</a>
                        <br>  <br>              
                        <a onclick="return confirm('Bạn có muốn xóa đơn đặt hàng đã chọn khỏi hệ thống')" href="Xem_Don_Hang_Khach_Hang.php?id=<?= $don_hang->id ?>" class='btn btn-danger'>Xóa đơn hàng</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="10" style="text-align: center; padding: 10px;">Không có đơn hàng nào.</td>
                </tr>
            <?php endif; ?>
            <!-- Thêm hàng hiển thị tổng số tiền cần thanh toán -->
            <tr>
                <td colspan="5"></td>
                <td><?= $tong_so_tien_thanh_toan ?></td>
                <td colspan="4"></td>
            </tr>
        </table>
    </div>

    <!-- Thêm phần thanh toán đơn hàng -->
    <div class="thanh-toan" style="margin-bottom: 50px;">
        <h3 style="color: blue;">Thanh toán đơn hàng</h3>
        <form action="process_thanh_toan.php" method="post" onsubmit="return validateForm()">
            <input type="radio" id="tt-online" name="thanh-toan" value="online">
            <label for="tt-online">Thanh toán trực tuyến</label><br>
            <input type="radio" id="tt-khi-nhan-hang" name="thanh-toan" value="khi-nhan-hang">
            <label for="tt-khi-nhan-hang">Thanh toán khi nhận hàng</label><br><br>

            <div id="phuong-thuc-thanh-toan">
                <!-- Dùng JavaScript để hiển thị mã QR hoặc chuyển hướng đến trang in hóa đơn -->
            </div>
            
            <button type="submit" id="btn-submit">Thanh toán</button>
        </form>
    </div>
</div>

<script>
    function validateForm()
    {
        var radios = document.getElementsByName("thanh-toan");
        var isChecked = false;
        for (var i = 0; i < radios.length; i++)
        {
            if (radios[i].checked) {
                isChecked = true;
                break;
            }
        }
        if (!isChecked)
        {
            alert("Vui lòng chọn hình thức thanh toán của bạn.");
            return false;
        }
        return true;
    }

    var btnSubmit = document.getElementById("btn-submit");
    btnSubmit.addEventListener("mouseover", function() {
        this.style.backgroundColor = "palegreen";
    });
    btnSubmit.addEventListener("mouseout", function() {
        this.style.backgroundColor = "whitesmoke";
    });
</script>
