<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thông tin tài khoản</title>
    
    <style>
        body {
            background-color: whitesmoke;
            font-family: 'Times New Roman', Times, serif;
            color: blue;
        }
        .container {
            width: 12cm;
            margin: 100px auto;
            background-color: gainsboro;
            border-radius: 6px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.7);           
        }
        form {
            font-size: 16px;
            color: blue;       
        }
        table {
            width: 100%;
        }
        table, th, td {
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        .textbox-container input[type="text"],
        .textbox-container input[type="password"] {
            width: calc(100% - 160px);
            padding: 10px;
            border: 1px solid blue;
            border-radius: 5px;
            margin-bottom: 10px;
            margin-left: 0%;
        }
        .button-container {
            text-align: center;
            margin-top: 20px;
        }
        .button {
            background-color: whitesmoke;
            border: 1px solid blue;
            border-radius: 4px;
            padding: 10px 20px;
            font-family: 'Times New Roman', Times, serif;
            font-size: 16px;
            color: blue;
            cursor: pointer;
            margin: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 style="text-align: center;">Thông tin tài khoản</h2>
        <form action="#" method="post">
            <table>
                <tr>
                    <th><label for="tb_MaID">Mã ID:</label></th>
                    <td class="textbox-container"><input type="text" id="tb_MaID" name="ma_id" readonly></td>
                </tr>
                <tr>
                    <th><label for="tb_ten_dang_nhap">Tên đăng nhập:</label></th>
                    <td class="textbox-container"><input type="text" id="tb_ten_dang_nhap" name="ten_dang_nhap" readonly></td>
                </tr>
                <tr>
                    <th><label for="tb_mat_khau">Mật khẩu:</label></th>
                    <td class="textbox-container"><input type="password" id="tb_mat_khau" name="mat_khau" readonly></td>
                </tr>
            </table>
            <div class="button-container">
                <button type="submit" name="submit" class="button">Hoàn thành</button>
                <button type="submit" name="submit" href="Loi_Mo_Dau.php" class="button">Trở lại</button>
            </div>
        </form>
    </div>

    <?php
    // Kết nối đến cơ sở dữ liệu MySQL
    $servername = "localhost";
    $username = "root"; // Thay bằng username của bạn
    $password = ""; // Thay bằng password của bạn, hoặc để trống nếu không có password
    $dbname = "project_demo"; // Tên cơ sở dữ liệu của bạn

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Kiểm tra kết nối
    if ($conn->connect_error) {
        die("Kết nối đến cơ sở dữ liệu thất bại: " . $conn->connect_error);
    }

    // Truy vấn dữ liệu từ bảng user
    $sql = "SELECT id, ten_dang_nhap, mat_khau FROM user";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Hiển thị dữ liệu vào các ô textbox
        $row = $result->fetch_assoc();
        echo "<script>
                document.getElementById('tb_MaID').value = '{$row['id']}';
                document.getElementById('tb_ten_dang_nhap').value = '{$row['ten_dang_nhap']}';
                document.getElementById('tb_mat_khau').value = '{$row['mat_khau']}';
              </script>";
    } else {
        echo "Không có dữ liệu";
    }

    $conn->close();
    ?>
</body>
</html>
