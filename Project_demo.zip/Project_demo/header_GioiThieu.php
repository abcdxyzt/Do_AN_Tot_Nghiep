<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đại lý thức ăn chăn nuôi Văn Lộc</title>
    <style>
        /* CSS */
        body {
            margin: 0;
            padding: 0;
            font-family: "Times New Roman", serif; /* Phông chữ Time New Roman */
            background-image: url('kanji_feed_background.jpg'); /* Đường dẫn đến hình nền */
            background-size: cover;
            background-position: center;
            color: black; /* Màu chữ đen */
            overflow-x: hidden; /* Ẩn phần dư thừa nếu có */
            position: relative;
        }

        header {
            background-color: palegreen; /* Màu nền của header là palegreen */
            padding: auto;
            height: 1.1cm;
            text-align: center;
            position: fixed;
            top: 0;
            left: 0;          
            width: 100%;
            z-index: 999; /* Đảm bảo header luôn hiển thị trên cùng */
        }

        .logo {
            display: block;
            margin: 10px 10px; /* Để logo căn giữa và cách lề trên 10px, lề trái 10px */
            max-width: 60px; /* Độ rộng tối đa của logo */
            height: auto; /* Chiều cao tự động tính dựa trên độ rộng */
            float: left; /* Đưa logo về phía trái */
            border-radius: 50px; /* Bo tròn góc */           
        }

        nav {
            display: flex; /* Sắp xếp các nút menu theo hàng ngang */
            justify-content: center; /* Căn giữa các menu */
            padding: 0px;
        }

        nav a {
            margin: 0 10px;
            text-decoration: none;
            color: black; /* Màu chữ đen */
            padding: 10px 20px;
            background-color: palegreen; /* Màu nền của các nút menu là palegreen */
            border-radius: 10px; /* Bo tròn góc */
        }

        nav a:hover {
            background-color: pink; /* Màu nền của menu khi rê chuột vào là pink */
        }
    </style>
</head>
<body>
    <header>
        <img src='/project_demo/Images/LOG2 - KANJI FEED VIỆT NAM.jpg' class='logo' alt='Kanji Feed Logo'>
        <nav>
            <a href="?page=home" data-i18n="home">Trang chủ</a>
            <a href="?page=about" data-i18n="about">Giới thiệu</a>
            <a href="?page=contact" data-i18n="contact">Liên hệ</a>
            <a href="?page=login" data-i18n="login">Đăng nhập tài khoản</a>
            <a href="dangky.php" data-i18n="register">Đăng ký tài khoản</a> <!-- Thêm menu Đăng ký tài khoản -->
        </nav>
    </header>
</body>
</html>
