<?php
require 'db.php';
include_once('ketnoi.php');

$sql = 'SELECT * FROM bang_gio_hang_khach_hang';
$statement = $connection->prepare($sql);
$statement->execute();
$gio_hang = $statement->fetchAll(PDO::FETCH_OBJ);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giỏ hàng của bạn</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            text-align: center;
            padding: 8px;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: palegreen;
        }
        h2 {
            text-align: center;
            color: red;
        }
    </style>
</head>
<body>
    <h2>Giỏ hàng của bạn</h2>
    <table>
        <thead>
            <tr>
                <th>Mã giỏ hàng</th>
                <th>Mã sản phẩm</th>
                <th>Tên sản phẩm</th>
                <th>Số lượng</th>
                <th>Đơn giá</th>
                <th>Thành tiền</th>
                <th>Hoạt động</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($gio_hang as $item): ?>
            <tr>
                <td><?= $item->ma_gio_hang; ?></td>
                <td><?= $item->ma_san_pham; ?></td>
                <td><?= $item->ten_san_pham; ?></td>
                <td><?= $item->so_luong_san_pham; ?></td>
                <td><?= $item->don_gia; ?></td>
                <td><?= $item->thanh_tien; ?></td>
                <td>
                    <a href="sua_gio_hang.php?id=<?= $item->ma_gio_hang; ?>">Sửa</a>
                    <a href="xoa_gio_hang.php?id=<?= $item->ma_gio_hang; ?>">Xóa</a>
                    <a href="dat_hang.php?id=<?= $item->ma_gio_hang; ?>">Đặt hàng</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
