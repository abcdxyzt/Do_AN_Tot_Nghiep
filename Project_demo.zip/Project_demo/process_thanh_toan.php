<?php require 'header_Loi_Mo_Dau.php';?>
<?php require 'footer.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thanh toán khi nhận hàng.</title>
    <style>
        body {
            font-family: 'Times New Roman', Times, serif;
            font-size: 16px;
            color: black;
            background-color: pink; /* Đổi màu nền thành palegreen */
            overflow-y: scroll; /* Thêm thanh cuộn */
        }
        .payment-form {
            background-color: Whitesmoke;
            margin-top: 50px;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            width: 40%;
            height: 40%;
            margin: 60px auto;
            box-shadow: 0 4px 8px rgba(0, 0, 255, 0.2);
            border: 2px solid blue; /* Màu viền blue */
            padding: 25px; /* Thêm độ phồng */
        }
        .payment-form label {
            display: block;
            margin-bottom: 3px; /* Giảm bớt khoảng cách giữa các dòng */
            text-align: justify;
        }
        .qr-code {
            width: 300px;
            height: 300px;
            margin: 0 auto; /* Canh giữa ảnh QR */
        }
        .btn {
            font-family: 'Times New Roman', Times, serif;
            font-size: 13px; /* Đổi cỡ chữ của nút button */
            width: auto;
            color: blue; /* Màu chữ blue */
            background-color: whitesmoke;
            padding: 14px 26px; /* Tăng kích thước của nút button */
            border: 2px solid blue;
            border-radius: 10px;
            margin-top: 20px; /* Giảm bớt khoảng cách từ nút button đến dòng Mã QR chuyển khoản */
            cursor: pointer;
            box-shadow: 0 4px 8px rgba(0, 0, 255, 0.2);
            margin-right: 1cm;
            font-weight: bold; /* In đậm chữ */
            transition: background-color 0.3s; /* Hiệu ứng khi hover */
        }
        .btn:hover {
            background-color: palegreen; /* Màu nền khi hover */
        }
        .btn:last-child {
            margin-right: 0;
        }
    </style>
</head>
<body>
    <?php
    require 'db.php';

    // Hàm đếm số lượng hàng mua
    function demSoLuongHangMua($ma_hoa_don) {
        // Sử dụng biến toàn cục $conn từ file db.php
        global $conn;
        $sql = "SELECT SUM(so_luong) AS tong_so_luong FROM don_hang WHERE ma_hoa_don = '$ma_hoa_don'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($result);
        return $row['tong_so_luong'];
    }

    // Kiểm tra xem có dữ liệu được gửi từ form không
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Kiểm tra xem người dùng đã chọn phương thức thanh toán nào
        if (isset($_POST['thanh-toan'])) {
            $thanh_toan = $_POST['thanh-toan'];

            // Nếu người dùng chọn thanh toán trực tuyến
            if ($thanh_toan === "online") {
                echo "<div class='payment-form'>";
                echo "<h2 style='color: red;'>THANH TOÁN TRỰC TUYẾN ĐƠN HÀNG</h2>";
                echo "<label><strong>Tên Ngân hàng:</strong> Ngân hàng Quân đội MB Bank</label><br>";
                echo "<label><strong>Số tài khoản:</strong> 270820020000</label><br>";
                echo "<label><strong>Tên tài khoản:</strong> LE VAN LOC</label><br>";
                echo "<img src='/project_demo/Images/Ma_QR_MB_Bank_LE_VAN_LOC.jpg' alt='QR Code' class='qr-code'><br>"; /* Sử dụng class để chỉnh css */
                echo "<label style='font-weight: bold; color: black; text-align: center; font-size: 20px;'>Mã QR chuyển khoản</label>"; /* Thêm CSS trực tiếp vào đây và đổi cỡ chữ */
                echo "<br>";
                echo "<button class='btn' onclick=\"window.location.href='Xem_Don_Hang_Khach_Hang.php'\">Trở lại Xem đơn hàng</button>";
                echo "<button class='btn' onclick=\"window.location.href='Loi_Mo_Dau.php'\">Trở lại giao diện đặt hàng</button>";
                echo "</div>";
            } 
            // Nếu người dùng chọn thanh toán khi nhận hàng
            elseif ($thanh_toan === "khi-nhan-hang") {
                // Lấy dữ liệu từ form Xem_Don_Hang_Khach_Hang.php
                $ma_hoa_don = $_POST['ma_hoa_don'];
                $ma_san_pham = $_POST['ma_san_pham'];
                $ten_san_pham = $_POST['ten_san_pham'];
                $so_luong = $_POST['so_luong'];
                $thong_tin_nguoi_mua = $_POST['thong_tin_nguoi_mua'];
                $dia_chi_khach_hang = $_POST['dia_chi_khach_hang'];
                $so_dien_thoai_khach_hang = $_POST['so_dien_thoai_khach_hang'];

                // Tính tổng số lượng hàng mua
                $tong_so_luong = demSoLuongHangMua($ma_hoa_don);

                // Tính tổng số tiền cần thanh toán
                $sql_tong_tien = "SELECT SUM(tong_tien) AS tong_tien FROM don_hang WHERE ma_hoa_don = '$ma_hoa_don'";
                $result_tong_tien = mysqli_query($conn, $sql_tong_tien);
                $row_tong_tien = mysqli_fetch_assoc($result_tong_tien);
                $tong_tien = $row_tong_tien['tong_tien'];

                // Tính ngày giao hàng dự kiến (ngày mai)
                $ngay_giao_hang_du_kien = date('Y-m-d', strtotime('+1 day'));

                // Hiển thị hóa đơn điện tử
                echo "<div class='payment-form'>";
                echo "<h2>Hóa đơn điện tử</h2>";
                echo "<table>";
                echo "<tr><td><strong>Mã ID:</strong></td><td>$thong_tin_nguoi_mua</td></tr>";
                echo "<tr><td><strong>Họ tên khách hàng:</strong></td><td>$thong_tin_nguoi_mua</td></tr>";
                echo "<tr><td><strong>Địa chỉ:</strong></td><td>$dia_chi_khach_hang</td></tr>";
                echo "<tr><td><strong>Số lượng hàng mua:</strong></td><td>$tong_so_luong</td></tr>";
                echo "<tr><td><strong>Tổng số tiền cần thanh toán:</strong></td><td>$tong_tien</td></tr>";
                echo "<tr><td><strong>Ngày giao hàng dự kiến:</strong></td><td>$ngay_giao_hang_du_kien</td></tr>";
                echo "</table>";
                echo "<br>";
                echo "<button class='btn' onclick=\"window.location.href='Xem_Don_Hang_Khach_Hang.php'\">Trở lại Xem đơn hàng</button>";
                echo "<button class='btn' onclick=\"window.location.href='Loi_Mo_Dau.php'\">Trở lại giao diện đặt hàng</button>";
                echo "</div>";
            } else {
                echo "Lỗi: Phương thức thanh toán không hợp lệ.";
            }
        } else {
            echo "Lỗi: Không có dữ liệu phương thức thanh toán được gửi.";
        }
    } else {
        echo "Lỗi: Yêu cầu không hợp lệ.";
    }
    ?>
</body>
</html>
