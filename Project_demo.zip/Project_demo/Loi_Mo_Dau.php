<!-- Tệp tin hiển thị giao diện danh sách các sản phẩm của cửa hàng để người dùng lựa chọn và đặt hàng.  -->
<?php
require 'db.php';

$sql = 'SELECT * FROM sanpham';
$statement = $connection->prepare($sql);
$statement->execute();
$list_san_pham = $statement->fetchAll(PDO::FETCH_OBJ);
?>
<?php require 'header_Loi_Mo_Dau.php';?>
<?php require 'footer.php';?>
<p style="padding-top: 29px;">DANH SÁCH SẢN PHẨM CỦA CỬA HÀNG THỨC ĂN CHĂN NUÔI VĂN LỘC.</p>
<link rel="stylesheet" type="text/css" href="CSS/Loi_Mo_Dau.css">

<div class="root">
    <!-- Ô tìm kiếm sản phẩm -->
    <div style="text-align: center;">
        <input style="margin-top:0%; text-align: justify; width: 16cm; height: 0.8cm; background-color: whitesmoke; font-family: 'Times New Roman', Times, serif; color: blue; border: 2px solid blue; border-radius: 8px;" class="tb_TimKiem" type="text" id="searchInput" placeholder="Nhập tên hoặc mã sản phẩm để tìm kiếm" required>
        <button style="width: 2cm; height: 0.8cm; background-color: whitesmoke; font-family: 'Times New Roman', Times, serif; color: blue; border: 2px solid blue; border-radius: 8px;" class="bt_NutTimKiem" id="bt_Search" onmouseover="this.style.backgroundColor='palegreen'" onmouseout="this.style.backgroundColor='whitesmoke'">Search</button>
        <button style="width: 2cm; height: 0.8cm; background-color: whitesmoke; font-family: 'Times New Roman', Times, serif; color: blue; border: 2px solid blue; border-radius: 8px;" class="bt_Xoa" id="bt_Xoa" onmouseover="this.style.backgroundColor='palegreen'" onmouseout="this.style.backgroundColor='whitesmoke'">Xóa</button>
    </div>    

    <?php foreach($list_san_pham as $san_pham): ?>
    <div style="width: 450px; height: 450px;" class="div-bg" id="div-img-bg1">

        <form action="dat_hang.php" method="GET"> <!-- Sửa action để chuyển đến trang dat_hang.php và method GET -->
            <table>
                <tr>
                    <td>Mã sản phẩm:</td>
                    <td><?= $san_pham->ma_san_pham; ?></td>
                </tr>
                <tr>
                    <td>Tên sản phẩm:</td>
                    <td><?= $san_pham->ten_san_pham; ?></td>
                </tr>
                <tr>
                    <td>Số lượng hiện có:</td>
                    <td><input type="text" name="tb_So_Luong_Hien_Co" id="tb_So_Luong_Hien_Co<?=$san_pham->ma_san_pham ?>" value="<?= $san_pham->so_luong; ?>" readonly style="font-family: 'Times New Roman'; font-size: 14px; width: 120px; border: 1px solid blue; background-color: white;"></td>
                </tr>
                <tr>
                    <td>Giá SP:</td>
                    <td>
                        <input type="text" name="gia_san_pham" id="gia_san_pham" value="<?= $san_pham->gia_san_pham; ?>" style="display:none;">
                        <?= $san_pham->gia_san_pham; ?> đồng/bao
                    </td>
                </tr>            
                <!-- <tr>
                    <td>Số lượng đặt:</td>
                    <td>
                        <input type="number" name="so_luong_san_pham <?=$san_pham->ma_san_pham ?>" id="so_luong_san_pham<?=$san_pham->ma_san_pham ?>" value="1" min="1" max="<?= $san_pham->so_luong; ?>" style="font-family: 'Times New Roman'; font-size: 14px; width: 120px; border: 1px solid blue;" onchange="calculateTotal('<?=$san_pham->ma_san_pham ?>')">
                        <span id="so_luong_error<?=$san_pham->ma_san_pham ?>" style="color: red; display: none;">Vui lòng nhập giá trị lớn hơn 0</span>
                    </td>
                </tr>
                <tr>
                    <td>Thành tiền:</td>
                    <td>
                        <input type="text" id="tb_Tong_So_Tien_Thanh_Toan<?=$san_pham->ma_san_pham ?>" name="tong_tien_san_pham<?=$san_pham->ma_san_pham ?>" value="<?= $san_pham->gia_san_pham; ?>" readonly style="font-family: 'Times New Roman'; font-size: 14px; width: 120px; border: 1px solid blue; background-color: white;"> đồng				       
                    </td>
                </tr> -->
            </table>
            <img src="Images/<?= $san_pham->anh_san_pham;?>" alt="" width="350px" height="240px">
            <button style="background-color: whitesmoke; color: blue; font-family: 'Times New Roman'; font-weight: bold; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.5); border-radius: 8px;" class="bt_mua_hang" type="submit" onmouseover="this.style.backgroundColor='palegreen'" onmouseout="this.style.backgroundColor='whitesmoke'">NHẤN ĐỂ ĐẶT HÀNG</button>
            <div> <span id= "nguoi_mua"></span></div>
            <input type="hidden" name="ten_san_pham" value="Thức ăn chăn nuôi" >
            <input type="hidden" name="ma_san_pham" value="<?= $san_pham->ma_san_pham ?>">
        </form>
    </div>
    <?php endforeach; ?>
</div>

<script>
    function calculateTotal(ma_san_pham)
    {
        var so_luong = document.getElementById("so_luong_san_pham" + ma_san_pham).value;
        var gia_san_pham = document.getElementById("gia_san_pham").value; // Sử dụng giá sản phẩm mới đã cập nhật
        var tong_tien = parseInt(so_luong) * parseInt(gia_san_pham);
        document.getElementById("tb_Tong_So_Tien_Thanh_Toan" + ma_san_pham).value = tong_tien;
    }
</script>

<script>
   document.getElementById("searchInput").addEventListener("keypress", function(event)
   {
    if (event.key === 'Enter')
    {
        event.preventDefault(); // Ngăn chặn hành động mặc định của phím Enter
        searchProduct();
    }
    });

    function searchProduct()
    {
        var keyword = document.getElementById("searchInput").value.toLowerCase();
        var products = document.getElementsByClassName("div-bg");
        for (var i = 0; i < products.length; i++) {
            var productName = products[i].getElementsByTagName("td")[1].innerText.toLowerCase();
            var productCode = products[i].getElementsByTagName("td")[3].innerText.toLowerCase();
            if (productName.indexOf(keyword) > -1 || productCode.indexOf(keyword) > -1) {
                products[i].style.display = "";
            } else {
                products[i].style.display = "none";
            }
        }
    }

    document.getElementById("bt_Search").addEventListener("click", function()
    {
        var keyword = document.getElementById("searchInput").value.toLowerCase();
        var products = document.getElementsByClassName("div-bg");
        for (var i = 0; i < products.length; i++) {
            var productName = products[i].getElementsByTagName("td")[1].innerText.toLowerCase();
            var productCode = products[i].getElementsByTagName("td")[3].innerText.toLowerCase();
            if (productName.indexOf(keyword) > -1 || productCode.indexOf(keyword) > -1) {
                products[i].style.display = "";
            } else {
                products[i].style.display = "none";
            }
        }
    });
    document.getElementById("bt_Xoa").addEventListener("click", function()
    {
        document.getElementById("searchInput").value = ""; // Xóa nội dung trong ô tìm kiếm
        window.location.reload(); // Reset lại trang web
    });        
</script>

</body>
</html>
