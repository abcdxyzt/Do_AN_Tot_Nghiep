<!-- Tệp này sử dụng để Xóa đơn hàng khi chọn Xóa đơn hàng trong tệp Xem_Don_Hang_Khach_Hang.php -->
<?php
require 'db.php';
if(isset($_GET['id']))
{
    $id = $_GET['id'];
    $sql = 'DELETE FROM donhang WHERE id=:id';
    $statement = $connection->prepare($sql);
    
    if($statement->execute([':id' => $id]))
    {
        header("Location: Xem_Don_Hang_Khach_Hang.php"); // Chuyển hướng về trang Sua_Don_Hang_Khach_Hang.php sau khi xóa thành công
    }
    else
    {
        echo(" Không thực hiện xóa đơn hàng.");
    }
}
?>
