<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> NHẬP THÔNG TIN ĐỂ ĐẶT HÀNG </title>
    <?php require 'header_Loi_Mo_Dau.php';?>
    <?php require 'footer.php';?>
    <style>
        body {
            font-family: "Times New Roman", Times, serif;
            color: blue;
        }

        .container {
            width: 18cm;
            margin-top: 0cm;
            margin-bottom: 0cm;
            height: 13cm;
            margin: 50px auto;
            padding: 20px;
            border: 2px solid blue;
            border-radius: 5px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.9);
            background-color: gainsboro;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        p {
            text-align: center;
            text-transform: uppercase;
            color: red;
            font-size: 19px;
            font-weight: bold;
        }

        label {
            display: table-row;
            font-weight: bold;
            margin-bottom: 5px;
            text-align: left;
        }

        input[type="text"], input[type="number"] {
            padding: 8px;
            margin-bottom: 5px;
            border: 1px solid blue;
            border-radius: 5px;
            font-family: "Times New Roman", Times, serif;
            color: blue;
            width: 12cm;
            box-sizing: border-box;
            text-align: left;
        }

        input[type="submit"], #bt_Xoa_Thong_Tin, #bt_Tro_Lai {
            background-color: whitesmoke;
            color: blue;
            border: 2px solid blue;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
            margin-top: 10px;
            width: fit-content;
            font-family: "Times New Roman", Times, serif;
            font-weight: bold;
            text-align: center;
        }

        #btn-group {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
        }

        input[type="submit"]:hover {
            background-color: palegreen;
        }

        #bt_Xoa_Thong_Tin:hover {
            background-color: lightcoral;
        }

        #bt_Tro_Lai:hover {
            background-color: pink;
        }
    </style>
</head>
<body>
    <div class="container">
        <p>THÔNG TIN ĐẶT HÀNG</p>
        <form action="" method="POST">
            <?php
                // Kiểm tra xem biến $_GET['ma_san_pham'] có tồn tại không
                if(isset($_GET['ma_san_pham'])){
                    $ma_san_pham = $_GET['ma_san_pham'];

                    // Tạo kết nối đến cơ sở dữ liệu
                    require 'db.php';

                    // Chuẩn bị truy vấn SQL để lấy thông tin sản phẩm dựa trên mã sản phẩm
                    $sql = 'SELECT * FROM sanpham WHERE ma_san_pham = ?';
                    $statement = $connection->prepare($sql);
                    $statement->execute([$ma_san_pham]);
                    $san_pham = $statement->fetch(PDO::FETCH_OBJ);
                } else {
                    echo "Mã sản phẩm không được cung cấp.";
                    // Nếu mã sản phẩm không được cung cấp, có thể chuyển hướng người dùng đến trang khác hoặc hiển thị thông báo lỗi
                    exit; // Kết thúc kịch bản nếu không có mã sản phẩm
                }

                // Xử lý khi nhấn nút "Đặt hàng"
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    // Lấy thông tin từ form
                    $ma_san_pham = $_POST["ma_san_pham"];
                    $ten_san_pham = $_POST["ten_san_pham"];
                    $so_luong = $_POST["so_luong"];
                    $gia_san_pham = $_POST["gia_san_pham"];
                    $thanh_tien = $_POST["thanh_tien"];
                    $thong_tin_nguoi_mua = $_POST["thong_tin_nguoi_mua"];
                    $dia_chi = $_POST["dia_chi"];
                    $so_dien_thoai = $_POST["so_dien_thoai"];

                    // Thực hiện truy vấn để chèn thông tin đặt hàng vào bảng donhang
                    $sql_insert = "INSERT INTO donhang (ma_san_pham, ten_san_pham, so_luong_san_pham, gia_san_pham, tong_so_tien, thong_tin_nguoi_mua, dia_chi_khach_hang, so_dien_thoai_khach_hang) 
                                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                    $statement_insert = $connection->prepare($sql_insert);
                    $statement_insert->execute([$ma_san_pham, $ten_san_pham, $so_luong, $gia_san_pham, $thanh_tien, $thong_tin_nguoi_mua, $dia_chi, $so_dien_thoai]);

                    // Thông báo đặt hàng thành công
                    echo "<script>alert('Đặt hàng thành công!');</script>";
                    // Chuyển hướng người dùng đến trang xem_hang_dat.php với mã sản phẩm
                    echo "<script>window.location.href = 'xem_hang_dat.php?ma_san_pham=$ma_san_pham';</script>";
                }
            ?>
            <table>
                <tr>
                    <th style="text-align: left;">Mã sản phẩm:</th>
                    <td><input type="text" id="ma_san_pham" name="ma_san_pham" value="<?= isset($san_pham->ma_san_pham) ? $san_pham->ma_san_pham : '' ?>" readonly></td>
                </tr>
                <tr>
                    <th style="text-align: left;">Tên sản phẩm:</th>
                    <td><input type="text" id="ten_san_pham" name="ten_san_pham" value="<?= isset($san_pham->ten_san_pham) ? $san_pham->ten_san_pham : '' ?>" readonly></td>
                </tr>
                <tr>
                    <th style="text-align: left;">Số lượng đặt hàng:</th>
                    <td><input type="number" id="so_luong" name="so_luong" min="1" required></td>
                </tr>
                <tr>
                    <th style="text-align: left;">Giá sản phẩm:</th>
                    <td><input type="text" id="gia_san_pham" name="gia_san_pham" value="<?= isset($san_pham->gia_san_pham) ? $san_pham->gia_san_pham : '' ?>" readonly></td>
                </tr>
                
                <tr>
                    <th style="text-align: left;">Thành tiền:</th>
                    <td><input type="text" id="thanh_tien" name="thanh_tien" readonly></td>
                </tr>
                <tr>
                    <th style="text-align: left;">Thông tin người mua:</th>
                    <td><input type="text" id="thong_tin_nguoi_mua" name="thong_tin_nguoi_mua" required></td>
                </tr>
                <tr>
                    <th style="text-align: left;">Địa chỉ:</th>
                    <td><input type="text" id="dia_chi" name="dia_chi" required></td>
                </tr>
                <tr>
                    <th style="text-align: left;">Số điện thoại:</th>
                    <td><input type="text" id="so_dien_thoai" name="so_dien_thoai" required></td>
                </tr>
            </table>
            <div id="btn-group">
                <input type="submit" value="Đặt hàng">
                <button id="bt_Xoa_Thong_Tin" onclick="clearInputs()">Xóa</button>
                <button id="bt_Tro_Lai" onclick="goBack()">Trở lại</button>
            </div>
        </form>
    </div>

    <script>
        function clearInputs() {
            document.getElementById("thong_tin_nguoi_mua").value = "";
            document.getElementById("dia_chi").value = "";
            document.getElementById("so_dien_thoai").value = "";
        }

        function goBack() {
            // Chuyển hướng người dùng đến trang Loi_Mo_Dau.php khi nhấn nút "Trở lại"
            window.location.href = 'Loi_Mo_Dau.php';
        }

        // Tính toán và hiển thị thành tiền
        document.getElementById("so_luong").addEventListener("input", function() {
            var soLuong = parseInt(document.getElementById("so_luong").value);
            var giaSanPham = parseInt(document.getElementById("gia_san_pham").value);
            var thanhTien = soLuong * giaSanPham;
            document.getElementById("thanh_tien").value = thanhTien + " đồng";
        });
    </script>
</body>
</html>
