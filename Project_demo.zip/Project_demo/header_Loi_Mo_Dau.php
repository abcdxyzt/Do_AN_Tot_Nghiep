<!DOCTYPE html>
<html lang="en">
<head>
    <title>Trang xem và đặt sản phẩm</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <style>
        @import url("CSS/TH06.css");      
        .navbar {
            border-radius: 6px;
            position: fixed;
            top: 0;
            left: 0;
            width: 200%; /* Đảm bảo menu chiếm toàn bộ chiều rộng của trình duyệt */
            height: 0.7cm;
            background-color: palegreen;
            overflow: hidden;
            display: flex; /* Sử dụng flexbox để căn chỉnh các thành phần bên trong */
            align-items: center; /* Căn các thành phần theo chiều dọc */
            padding: 10px; /* Khoảng cách giữa logo và các nút menu */
            box-shadow: 0 0 8px rgba(0, 0, 0, 1.5); /* Hiệu ứng đổ bóng cho menu */
        }
        
        .navbar a {
            display: flex; /* Sắp xếp các nút menu theo hàng ngang */
            justify-content: center; /* Căn giữa các menu */
            padding: 10px;
            color: blue;
            margin-bottom: 0cm;     
            text-align: center;
            text-decoration: none;
            font-size: 17px;
            margin-right: 10px; /* Khoảng cách giữa các nút menu */
            margin-left: 0.9px; /* Dịch nút menu sang bên phải */
        }
        .navbar a:hover {
            background-color: pink; /* Màu nền khi di chuột qua */
        }
        .logo
        {            
            display: block;
            margin: 10px 10px; /* Để logo căn giữa và cách lề trên 10px, lề trái 10px */
            max-width: 60px; /* Độ rộng tối đa của logo */
            height: auto; /* Chiều cao tự động tính dựa trên độ rộng */
            float: left; /* Đưa logo về phía trái */
            border-radius: 50px; /* Bo tròn góc */ 
        }
        a
        {
            border-radius: 10px;            
        }
    </style>
</head>
<body class=""> 
    <div class="navbar">
        <img src="/project_demo/Images/LOG2 - KANJI FEED VIỆT NAM.jpg" class="logo" alt="Kanji Feed Logo">
        <a href="Loi_Mo_Dau.php">Trang chủ</a>
        <a href="DangNhap_QuanTriVien.php">Đăng nhập quản trị viên</a>
        <a href="http://zalo.me/0356461193">Liên hệ với cửa hàng</a>
        <a href="Xem_Don_Hang_Khach_Hang.php">Xem đơn hàng đã đặt</a>
        <a href="Gio_Hang_Khach_Hang.php">Xem Giỏ hàng của bạn</a>
        <a href="logout.php">Đăng xuất</a>
    </div>
</body>
</html>
