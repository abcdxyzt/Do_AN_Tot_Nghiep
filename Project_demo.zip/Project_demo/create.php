<?php require 'db.php'; ?>

<?php
$message = '';

if (isset($_POST['ma_san_pham']) && isset($_POST['ten_san_pham'])) {
    $ma_san_pham = $_POST['ma_san_pham'];
    $ten_san_pham = $_POST['ten_san_pham'];
    $gia_san_pham = $_POST['gia_san_pham'];
    $anh_san_pham = $_POST['anh_san_pham'];
    $so_luong = $_POST['so_luong'];
    $sql = 'INSERT INTO sanpham(ma_san_pham, ten_san_pham, gia_san_pham, anh_san_pham, so_luong) VALUES(:ma_san_pham, :ten_san_pham, :gia_san_pham, :anh_san_pham, :so_luong)';
    $statement = $connection->prepare($sql);
    if ($statement->execute([':ma_san_pham' => $ma_san_pham, ':ten_san_pham' => $ten_san_pham, ':gia_san_pham' => $gia_san_pham, ':anh_san_pham' => $anh_san_pham, ':so_luong' => $so_luong])) {
        header("Location: /Project_demo/list_san_pham.php");
    }
}
?>

<?php require 'header_admin.php'; ?>
<link rel="stylesheet" href="CSS/ThemSanPham.css">

<div style="display: flex; justify-content: center; align-items: center; height: 100vh; margin-top: 10px;" class="container">
    <div style="padding: 20px; border: 1px solid grey; box-shadow: 0 0 10px red (0, 0, 0, 3.0); border-radius: 12px; width: 500px; height: 400px; background-color: whitesmoke;" class="card">
        <h2 style="color: red; text-align: center; margin-top: 0%; font-weight: bold;">Thêm sản phẩm vào hệ thống</h2>

        <form method="POST" action="">
            <div class="form-group">
                <label style="font-weight: bold; color: blue; font-size: 20px; width: 150px; display: inline-block; font-family: 'Times New Roman', Times, serif;" for="ma_san_pham">Mã sản phẩm</label>
                <input style="height: 25px; border-radius: 5px; border: 1px solid blue; color: blue; width: calc(100% - 170px); display: inline-block; font-family: 'Times New Roman', Times, serif;" type="text" name="ma_san_pham" id="ma_san_pham" required>
            </div>

            <div class="form-group">
                <label style="font-weight: bold; color: blue; font-size: 20px; width: 150px; display: inline-block; font-family: 'Times New Roman', Times, serif;" for="ten_san_pham">Tên sản phẩm</label>
                <input style="height: 25px; border-radius: 5px; border: 1px solid blue; color: blue; width: calc(100% - 170px); display: inline-block; font-family: 'Times New Roman', Times, serif;" type="text" name="ten_san_pham" id="ten_san_pham" required>
            </div>

            <div class="form-group">
                <label style="font-weight: bold; color: blue; font-size: 20px; width: 150px; display: inline-block; font-family: 'Times New Roman', Times, serif;" for="gia_san_pham">Giá sản phẩm</label>
                <input style="height: 25px; border-radius: 5px; border: 1px solid blue; color: blue; width: calc(100% - 170px); display: inline-block; font-family: 'Times New Roman', Times, serif;" type="text" name="gia_san_pham" id="gia_san_pham" required>
            </div>

            <div class="form-group">
                <label style="font-weight: bold; color: blue; font-size: 20px; width: 150px; display: inline-block; font-family: 'Times New Roman', Times, serif;" for="so_luong">Số lượng</label>
                <div style="display: inline-block;">
                    <button type="button" onclick="decreaseQuantity()" style="height: 25px; font-family: 'Times New Roman', Times, serif;">-</button>
                    <input style="width: 50px; height: 25px; border-radius: 5px; border: 1px solid blue; color: blue; text-align: center; display: inline-block; font-family: 'Times New Roman', Times, serif;" type="text" name="so_luong" id="so_luong" value="1" required>
                    <button type="button" onclick="increaseQuantity()" style="height: 25px; font-family: 'Times New Roman', Times, serif;">+</button>
                </div>
            </div>

            <div class="form-group">
                <label style="font-weight: bold; color: blue; font-size: 20px; width: 150px; display: inline-block; font-family: 'Times New Roman', Times, serif;" for="anh_san_pham">Ảnh sản phẩm</label>
                <div style="display: inline-block; align-items: center;">
                    <input style="width: 75%; height: 25px; border-radius: 5px; border: 1px solid blue; color: blue; display: inline-block; font-family: 'Times New Roman', Times, serif;" type="text" name="anh_san_pham" id="anh_san_pham" readonly required>
                    <input style="display: none;" type="file" accept="image/*" name="anh_san_pham_input" id="anh_san_pham_input" onchange="displayFileName()">
                    <button style="font-weight: bold; color: blue; border: 1px solid blue; background-color: palegreen; height: 25px; font-family: 'Times New Roman', Times, serif; width: auto;" onclick="document.getElementById('anh_san_pham_input').click();" type="button">Tải ảnh</button>
                </div>
            </div>

            <div class="button-group" style="display: flex; justify-content: center; gap: 10px; margin-top: 10px;">
                <button style="font-weight: bold; color: blue; border: 1px solid blue; background-color: palegreen; height: 25px; font-family: 'Times New Roman', Times, serif;" type="submit">Thêm mới</button>
                <button style="font-weight: bold; color: red; border: 1px solid red; background-color: lightcoral; height: 25px; font-family: 'Times New Roman', Times, serif;" type="button" onclick="resetForm()">Xóa bỏ</button>
            </div>
        </form>
    </div>
</div>

<script>
    function displayFileName() {
        var fileInput = document.getElementById('anh_san_pham_input');
        var fileName = fileInput.files[0].name;
        document.getElementById('anh_san_pham').value = fileName;
    }

    function resetForm() {
        document.getElementById("ma_san_pham").value = "";
        document.getElementById("ten_san_pham").value = "";
        document.getElementById("gia_san_pham").value = "";
        document.getElementById("anh_san_pham").value = "";
    }

    function increaseQuantity() {
        var quantityInput = document.getElementById('so_luong');
        var currentQuantity = parseInt(quantityInput.value);
        quantityInput.value = currentQuantity + 1;
    }

    function decreaseQuantity() {
        var quantityInput = document.getElementById('so_luong');
        var currentQuantity = parseInt(quantityInput.value);
        if (currentQuantity > 1) {
            quantityInput.value = currentQuantity - 1;
        }
    }
</script>

<?php require 'footer.php'; ?>
