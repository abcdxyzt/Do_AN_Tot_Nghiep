<?php
require 'db.php';
if(isset($_POST['id_san_pham']))
{   
    $ma_gio_hang = $_POST['ma_gio_hang'];
    $ma_san_pham = $_POST['ma_san_pham'];
    $ten_san_pham = $_POST['ten_san_pham'];
    $so_luong_san_pham = $_POST['so_luong_san_pham'];
    $don_gia = $_POST['don_gia'];
    $thanh_tien = $_POST['thanh_tien'];
    
    $sql = 'INSERT INTO bang_gio_hang_khach_hang(ma_gio_hang, ma_san_pham, ten_san_pham, so_luong_san_pham, don_gia, thanh_tien) VALUES (:ma_gio_hang,:ma_san_pham, :ten_san_pham, :so_luong_san_pham, :don_gia, :thanh_tien)';
    $statement = $connection->prepare($sql);
    if ($statement->execute([
        ':ma_gio_hang' => $ma_gio_hang,
        ':ma_san_pham' => $ma_san_pham,
        ':ten_san_pham' => $ten_san_pham,
        ':so_luong_san_pham' => $so_luong_san_pham,
        ':don_gia' => $don_gia,
        ':thanh_tien' => $thanh_tien
    ]))
    {
        echo "<p>Thêm vào giỏ hàng thành công!</p>";      
        header("Location: /Project_demo/Loi_Mo_Dau.php");
    }
    else
    {        
        echo "<p>Lỗi, không thêm được</p>";
    }
}
?>
