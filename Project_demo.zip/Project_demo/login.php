<?php
session_start();
if(isset($_POST['submit'])) {
    require 'db.php';
    $tai_khoan = $_POST['tai_khoan'];
    $password = $_POST['password'];
    $sql = 'SELECT * FROM user WHERE ten_dang_nhap=:ten_dang_nhap';
    $statement = $connection->prepare($sql);
    $statement->execute([':ten_dang_nhap' => $tai_khoan ]);
    $user = $statement->fetch(PDO::FETCH_OBJ); 
    if($user != null && $user->mat_khau == $password)
    {
        $lifetime = 24*60*60;
        $_SESSION['email'] = $email;
        setcookie('lifetime',time()+$lifetime);
        setcookie($tai_khoan, $password,$lifetime, "/");
        header('Location: Loi_Mo_Dau.php'); // Thay đổi đường dẫn ở đây
        exit(); // Đảm bảo không có mã HTML hoặc dữ liệu được gửi đi sau lệnh header
    }
    else
    {
        echo '<p style="color:red;"> Thông báo: Tên đăng nhập hoặc mật khẩu không đúng. Hãy đăng nhập lại! </p>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập tài khoản</title>
    <link rel="stylesheet" type="text/css" href="CSS/DangNhapNguoiDungLogin.css">
    
</head>
<body>
    <form style="height: auto;" action="<?php echo  htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
        <h3>NHẬP THÔNG TIN ĐĂNG NHẬP</h3>
        <table>
            <tr>
                <td><label for="tb_ID_Khach_Hang">Mã ID:</label></td>
                <td><input type="text" placeholder="Nhập mã ID" id="tb_ID_Khach_Hang" name="tb_ID_Khach_Hang"></td>
            </tr>
            <tr>
                <td><label for="tai_khoan">Tên đăng nhập:</label></td>
                <td><input class="TaiKhoan" type="text" placeholder="Nhập tên đăng nhập" id="tai_khoan" name="tai_khoan" required></td>
            </tr>
            <tr>
                <td><label for="password">Mật khẩu:</label></td>
                <td><input class="MatKhau" type="password" placeholder="Nhập mật khẩu" id="password" name="password" required></td>
            </tr>
        </table>
        <button class="button_DangNhap_NguoiDung" type="submit" name="submit"> ĐĂNG NHẬP </button>
        <ul style="text-align: justify;" class="custom-list">
            <li style="margin-bottom: 0.5cm;">
                <a style="text-align: left;" href='dangky.php'>Đăng ký tài khoản</a>
            </li>
            <li style="margin-bottom: 0.5cm;">
                <a style="text-align: left;" href='quen_mat_khau.php'>Quên Mật khẩu</a> <!-- Thêm đường link quên mật khẩu -->
            </li>
            <li style="margin-bottom: 0.5cm;">
                <a style="text-align: left;" href='DangNhap_QuanTriVien.php'>Đăng nhập Quản trị viên</a>
            </li>
            <li>
                <a style="text-align: left;" href='GioiThieuVeTrang.php'>Trở lại</a>
            </li>
        </ul>
    </form>    
</body>
<?php require 'footer.php'; ?>
</html>
