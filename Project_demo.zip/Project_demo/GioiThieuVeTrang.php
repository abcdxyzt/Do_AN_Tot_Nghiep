<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đại lý thức ăn chăn nuôi Văn Lộc</title>
    <style>
        /* CSS */
        body {
            margin: 0;
            padding: 0;
            font-family: "Times New Roman", serif; /* Phông chữ Time New Roman */
            background-image: url('kanji_feed_background.jpg'); /* Đường dẫn đến hình nền */
            background-size: cover;
            background-position: center;
            color: black; /* Màu chữ đen */
            overflow-x: hidden; /* Ẩn phần dư thừa nếu có */
            position: relative;
        }

        header {
            background-color: palegreen; /* Màu nền của header là palegreen */
            padding: auto;
            height: 1.3cm;
            text-align: center;
            position: fixed;
            top: 0;
            left: 0;          
            width: 100%;
            z-index: 999; /* Đảm bảo header luôn hiển thị trên cùng */
        }

        .logo {
            display: block;
            margin: 10px 10px; /* Để logo căn giữa và cách lề trên 10px, lề trái 10px */
            max-width: 60px; /* Độ rộng tối đa của logo */
            height: auto; /* Chiều cao tự động tính dựa trên độ rộng */
            float: left; /* Đưa logo về phía trái */
            border-radius: 10px; /* Bo tròn góc */
        }

        nav {
            display: flex; /* Sắp xếp các nút menu theo hàng ngang */
            justify-content: center; /* Căn giữa các menu */
            padding: 10px;
        }

        nav a {
            margin: 0 10px;
            text-decoration: none;
            color: black; /* Màu chữ đen */
            padding: 10px 20px;
            background-color: palegreen; /* Màu nền của các nút menu là palegreen */
            border-radius: 10px; /* Bo tròn góc */
        }

        nav a:hover {
            background-color: pink; /* Màu nền của menu khi rê chuột vào là pink */
        }

        .content {
            padding: 20px;
            text-align: center;
            overflow-y: auto; /* Thêm thanh cuộn khi nội dung quá dài */
            max-height: calc(100vh - 200px); /* Giới hạn chiều cao của nội dung để tránh che phần chân */
            margin-top: 50px; /* Dịch nội dung xuống dưới header */
        }

        footer
        {
            background-color: gray;           
            color: blue; /* Màu chữ trắng */
            padding: 0%;
            text-align: center;
            position: fixed;
            bottom: 0;
            height: auto;
            width: 100%; /* Thay đổi chiều rộng của footer để phù hợp với trang */
        }

        /* Additional CSS for the new homepage */
        .home-page {
            background-color: #f9f9f9;
            font-family: 'Times New Roman', Times, serif;
            padding: 20px;
            text-align: justify; /* Căn đều hai bên */
            text-indent: 50px; /* Thụt đầu dòng */
            color: black; /* Màu chữ đen */
        }

        .home-page h2 {
            color: black; /* Màu chữ đen */
            text-align: center; /* Căn giữa dòng chữ */
        }

        .home-page p {
            color: black; /* Màu chữ đen */
            margin-bottom: 10px;
        }

        .large-text {
            font-size: 19px;
            color: black; /* Màu chữ đen */
        }

        /* Style for language dropdown */
        .language-dropdown {
            position: fixed;
            top: 10px;
            right: 10px;
            font-family: "Times New Roman", serif; /* Phông chữ Time New Roman */
            font-size: 12px;
            color: blue;
            z-index: 1000;
        }
    </style>
</head>
<body>
    <?php include 'header_GioiThieu.php'; ?>
    <!-- Language dropdown -->
    <div class="language-dropdown">
        <select style="font-family: 'Times New Roman', Times, serif; color: black;" onchange="changeLanguage(this.value)">
            <option value="vi">Tiếng Việt</option>
            <option value="en">English</option>
        </select>
    </div>

    <div class="content">
        <?php
        // Kiểm tra nếu không có tham số page hoặc tham số page là trang chủ
        if (!isset($_GET['page']) || $_GET['page'] === 'home') {
            echo "<div class='home-page'>";
            // Chèn hình ảnh logo
            echo "<h2 data-i18n='welcome_heading'>CHÀO MỪNG QUÝ KHÁCH HÀNG ĐẾN TÌM HIỂU VỀ CÁC SẢN PHẨM CỦA CỬA HÀNG THỨC ĂN CHĂN NUÔI VĂN LỘC.</h2>";
            echo "<p class='large-text' data-i18n='welcome_message'><strong>Chào mừng quý khách đến với Cửa hàng Thức ăn Chăn nuôi Văn Lộc!</strong></p>";
            echo "<p class='large-text' data-i18n='products_quality'>Chúng tôi tự hào là địa chỉ đáng tin cậy, cung cấp các sản phẩm thức ăn chất lượng cao cho heo, gà, cá, vịt và bò. Đặc biệt, các sản phẩm thức ăn chăn nuôi được cung cấp bởi Công ty Cổ phần Kanji Feed Việt Nam, có trụ sở tại Hưng Yên - Việt Nam. Với nguồn gốc rõ ràng và sự cam kết đảm bảo chất lượng, quý khách hàng có thể yên tâm khi lựa chọn sản phẩm từ cửa hàng của chúng tôi.</p>";
            echo "<p class='large-text' data-i18n='customer_experience'>Chúng tôi không chỉ mang đến những sản phẩm chất lượng mà còn cam kết đem lại trải nghiệm mua sắm thoải mái và tiện lợi nhất cho bà con trên hành trình chăm sóc và nuôi dưỡng đàn vật nuôi của mình.</p>";
            echo "<p class='large-text' data-i18n='address'>Địa chỉ: Thôn 2, Thôn 3 - Xã Ba Trại - Huyện Ba Vì - TP Hà Nội.</p>";
            echo "</div>";
        } else {
            // Xử lý việc hiển thị nội dung tương ứng với menu được chọn
            $page = $_GET['page'];
            switch ($page) {
                case 'about':
                    echo "<div class='home-page'>";
                    echo "<h2 data-i18n='introduction_heading'>GIỚI THIỆU</h2>";
                    echo "<p class='large-text' data-i18n='introduction_content'>Với vị thế là chi nhánh của Công ty cổ phần Kanji Feed Việt Nam, cửa hàng thức ăn chăn nuôi Văn Lộc luôn đặt lợi ích khách hàng lên hàng đầu với các sản phẩm thức ăn chăn nuôi chất lượng cao, có nguồn gốc xuất xứ rõ ràng, giá cả hợp lý. Bên cạnh đó, chúng tôi còn có nhiều chương trình khuyến mãi, đổi thưởng khi bạn là khách hàng thân thiết, tiềm năng của chúng tôi. Cửa hàng chuyên cung cấp các loại thức ăn chăn nuôi cho các loài gồm: Heo, gà, trâu, bò, ngan, vịt, cá,.. Bên cạnh đó, chúng tôi cũng có thể có các tư vấn hữu ích cho khách hàng để đồng hành cùng khách hàng trên hành trình phát triển kinh tế ngành chăn nuôi nói riêng và ngành nông nghiệp Việt Nam nói chung.</p>";
                    echo "</div>";
                    break;
                case 'contact':
                    echo "<h2 data-i18n='contact_heading' style='text-align: center; text-indent: 0.5cm;'>Thông tin liên hệ</h2>";
                    echo "<p style='text-align: justify; text-indent: 0.5cm;' data-i18n='facebook_contact'>Liên hệ qua Facebook: <a href='https://www.facebook.com/profile.php?id=100025648987643'>Lê Văn Lộc</a></p>";
                    echo "<p style='text-align: justify; text-indent: 0.5cm;' data-i18n='zalo_contact'>Liên hệ qua Zalo:</p>";
                    echo "<li style='margin-bottom: 0.5cm; text-align: justify; text-indent: 0.5cm;'><a href='http://zalo.me/0356461193'>0356461193</a></li>"; // Thiết lập margin cho từng mục danh sách
                    echo "<li style='margin-bottom: 0.5cm; text-align: justify; text-indent: 0.5cm;'><a href='http://zalo.me/0969630992'>0969630992</a></li>";
                    break;
                case 'login': // Trang đăng nhập
                    //  include('login.php');                  
                    echo "<h2 data-i18n='login'>Đăng nhập</h2>";
                    echo "<li style='text-align: justify; text-indent: 0.5cm; margin-bottom: 0.5cm;'><a style='text-align: left;' href='DangNhap_QuanTriVien.php' data-i18n='admin_login'>Đăng nhập tài khoản quản trị viên</a></li>";
                    echo "<li style='text-align: justify; text-indent: 0.5cm; margin-bottom: 0.5cm;'><a style='text-align: left;' href='login.php' data-i18n='user_login'>Đăng nhập tài khoản người dùng (Khách hàng)</a></li>";
                    break;
            }
        }
        ?>
    </div>

    <footer class="footer">
        <div class="footer-content">        
            <p style="color: white;" data-i18n="address">Địa chỉ: Thôn 2; Thôn 3 - Xã Ba Trại - Huyện Ba Vì - TP Hà Nội.</p>
            <p style="color: white;" data-i18n="phone_numbers">Số điện thoại: 0356461193 - 0969630992.</p> 
        </div>        
    </footer>

    <script>
        // JavaScript
        window.addEventListener('scroll', function() {
            var footer = document.querySelector('.footer');
            var footerContent = document.querySelector('.footer-content');
            var windowHeight = window.innerHeight;
            var scrollY = window.scrollY || window.pageYOffset;
            var footerOffsetTop = footer.offsetTop;

            if ((scrollY + windowHeight) >= footerOffsetTop) {
                footerContent.classList.add('show');
            } else {
                footerContent.classList.remove('show');
            }
        });

        // Function to change language
        function changeLanguage(language) {
            // Define language mapping
            const languageMap = {
                'vi': {
                    'home': 'Trang chủ',
                    'about': 'Giới thiệu',
                    'contact': 'Liên hệ',
                    'login': 'Đăng nhập tài khoản',
                    'register': 'Đăng ký tài khoản',
                    'welcome_message': 'CHÀO MỪNG QUÝ KHÁCH HÀNG ĐẾN TÌM HIỂU VỀ CÁC SẢN PHẨM CỦA CỬA HÀNG THỨC ĂN CHĂN NUÔI VĂN LỘC.',
                    'welcome_heading': 'Chào mừng quý khách đến với Cửa hàng Thức ăn Chăn nuôi Văn Lộc!',
                    'products_quality': 'Chúng tôi tự hào là địa chỉ đáng tin cậy, cung cấp các sản phẩm thức ăn chất lượng cao cho heo, gà, cá, vịt và bò. Đặc biệt, các sản phẩm thức ăn chăn nuôi được cung cấp bởi Công ty Cổ phần Kanji Feed Việt Nam, có trụ sở tại Hưng Yên - Việt Nam. Với nguồn gốc rõ ràng và sự cam kết đảm bảo chất lượng, quý khách hàng có thể yên tâm khi lựa chọn sản phẩm từ cửa hàng của chúng tôi.',
                    'customer_experience': 'Chúng tôi không chỉ mang đến những sản phẩm chất lượng mà còn cam kết đem lại trải nghiệm mua sắm thoải mái và tiện lợi nhất cho bà con trên hành trình chăm sóc và nuôi dưỡng đàn vật nuôi của mình.',
                    'address': 'Địa chỉ: Thôn 2, Thôn 3 - Xã Ba Trại - Huyện Ba Vì - TP Hà Nội.',
                    'introduction_heading': 'GIỚI THIỆU',
                    'introduction_content': 'Với vị thế là chi nhánh của Công ty cổ phần Kanji Feed Việt Nam, cửa hàng thức ăn chăn nuôi Văn Lộc luôn đặt lợi ích khách hàng lên hàng đầu với các sản phẩm thức ăn chăn nuôi chất lượng cao, có nguồn gốc xuất xứ rõ ràng, giá cả hợp lý. Bên cạnh đó, chúng tôi còn có nhiều chương trình khuyến mãi, đổi thưởng khi bạn là khách hàng thân thiết, tiềm năng của chúng tôi. Cửa hàng chuyên cung cấp các loại thức ăn chăn nuôi cho các loài gồm: Heo, gà, trâu, bò, ngan, vịt, cá,.. Bên cạnh đó, chúng tôi cũng có thể có các tư vấn hữu ích cho khách hàng để đồng hành cùng khách hàng trên hành trình phát triển kinh tế ngành chăn nuôi nói riêng và ngành nông nghiệp Việt Nam nói chung.',
                    'contact_heading': 'Thông tin liên hệ',
                    'facebook_contact': 'Liên hệ qua Facebook:',
                    'zalo_contact': 'Liên hệ qua Zalo:',
                    'phone_numbers': 'Số điện thoại: 0356461193 - 0969630992.',
                    'admin_login': 'Đăng nhập tài khoản quản trị viên',
                    'user_login': 'Đăng nhập tài khoản người dùng (Khách hàng)'
                },
                'en': {
                    'home': 'Home',
                    'about': 'About',
                    'contact': 'Contact',
                    'login': 'Log in',
                    'register': 'Register',
                    'welcome_message': 'WELCOME TO VAN LOC ANIMAL FEED STORE!',
                    'welcome_heading': 'Welcome to Van Loc Animal Feed Store!',
                    'products_quality': 'We are proud to be a reliable address, providing high-quality feed products for pigs, chickens, fish, ducks, and cows. In particular, our animal feed products are provided by Kanji Feed Vietnam Joint Stock Company, headquartered in Hung Yen - Vietnam. With clear origin and a commitment to quality assurance, customers can rest assured when choosing products from our store.',
                    'customer_experience': 'We not only bring quality products, but also commit to providing the most comfortable and convenient shopping experience for customers on the journey of caring for and nurturing their livestock.',
                    'address': 'Address: Hamlet 2, Hamlet 3 - Ba Trai Commune - Ba Vi District - Hanoi City.',
                    'introduction_heading': 'INTRODUCTION',
                    'introduction_content': 'As a branch of Kanji Feed Vietnam Joint Stock Company, Van Loc animal feed store always prioritizes customer interests with high-quality animal feed products, clear origins, and reasonable prices. Besides, we also have many promotion programs, rewards when you are our loyal and potential customers. The store specializes in providing animal feed for species including: pigs, chickens, buffaloes, cows, geese, ducks, fish, .. Besides, we can also have useful advice for customers to accompany customers on the journey of developing the economy of the livestock industry in particular and the agriculture industry of Vietnam in general.',
                    'contact_heading': 'Contact Information',
                    'facebook_contact': 'Contact via Facebook:',
                    'zalo_contact': 'Contact via Zalo:',
                    'phone_numbers': 'Phone numbers: 0356461193 - 0969630992.',
                    'admin_login': 'Log in as an administrator',
                    'user_login': 'Log in as a user (Customer)'
                }
            };

            // Get all elements with data-i18n attribute
            const elements = document.querySelectorAll('[data-i18n]');
            // Loop through each element to translate its content
            elements.forEach(element => {
                const key = element.getAttribute('data-i18n');
                if (languageMap[language] && languageMap[language][key]) {
                    element.innerHTML = languageMap[language][key];
                }
            });
        }
    </script>
</body>
</html>
