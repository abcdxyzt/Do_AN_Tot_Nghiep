<?php
// Kết nối đến cơ sở dữ liệu
require 'db.php';

// Kiểm tra xem có tham số id được truyền từ URL không
if(isset($_GET['id'])) {
    // Lấy id từ URL
    $id = $_GET['id'];

    try {
        // Chuẩn bị câu truy vấn xóa tài khoản người dùng
        $sql = "DELETE FROM user WHERE id = ?";
        $statement = $connection->prepare($sql);

        // Bind tham số id vào câu truy vấn
        $statement->bindParam(1, $id);

        // Thực thi câu truy vấn
        $statement->execute();

        // Lấy thông tin tài khoản đã xóa
        $sql_select_deleted_user = "SELECT * FROM user WHERE id = ?";
        $statement_select_deleted_user = $connection->prepare($sql_select_deleted_user);
        $statement_select_deleted_user->execute([$id]);
        $deleted_user = $statement_select_deleted_user->fetch(PDO::FETCH_OBJ);

        // Xuất thông báo về việc xóa tài khoản thành công
        $message = "Thông báo: Tài khoản có mã ID là $deleted_user->id và tên đăng nhập là $deleted_user->ten_dang_nhap đã được xóa thành công";
        echo "<script>alert('$message');</script>";

        // Chuyển hướng người dùng về trang quản lý tài khoản người dùng sau khi xóa thành công
        header("Location: quan_ly_tai_khoan_nguoi_dung.php");
        exit();
    } catch(PDOException $e) {
        // Xử lý nếu có lỗi xảy ra
        echo "Lỗi: " . $e->getMessage();
    }
} else {
    // Nếu không có id truyền vào từ URL, chuyển hướng người dùng về trang quản lý tài khoản người dùng
    header("Location: quan_ly_tai_khoan_nguoi_dung.php");
    exit();
}
?>
